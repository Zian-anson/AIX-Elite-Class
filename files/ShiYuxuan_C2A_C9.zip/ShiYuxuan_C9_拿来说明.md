# 拿来说明 / Attribution

**作者 / Author:** ShiYuxuan
**挑战 / Challenge:** C9 — Track 2 Metacognition
**日期 / Date:** 2026-04-11

---

## 借鉴来源 / References

| 来源 | 链接 | 核心思想 |
|------|------|----------|
| MMLU (Hendrycks et al., 2021) | [arXiv:2009.03300](https://arxiv.org/abs/2009.03300) | 多领域知识评估框架；直接用作维度 C 追问链的话题 |
| TruthfulQA (Lin et al., 2022) | [arXiv:2109.07958](https://arxiv.org/abs/2109.07958) | 测试 AI 是否给出看似合理但虚假的答案 |
| Kadavath et al. (2022) | [arXiv:2207.05221](https://arxiv.org/abs/2207.05221) | 模型内部置信度信号与输出置信度不一致的基础研究；支持"知道但不说"假设 |
| Guo et al. (2017) | [ICML 2017](https://arxiv.org/abs/1706.04599) | ECE 标准计算公式 |
| Ouyang et al. (2022) | [arXiv:2203.02155](https://arxiv.org/abs/2203.02155) | RLHF 原始论文；理解沉默机制的训练根源 |
| Perez et al. (2022) | [arXiv:2212.09251](https://arxiv.org/abs/2212.09251) | Sycophancy in LLMs；奉承偏差的定义和测量 |
| DeepMind AGI 框架 (2026) | [PDF](https://storage.googleapis.com/deepmind-media/DeepMind.com/Blog/measuring-progress-toward-agi/measuring-progress-toward-agi-a-cognitive-framework.pdf) | Track 2 元认知评估缺口定义；ΔE 概念 |
| KSTAR 框架 | 课程资料 | S（情境评估）和 ΔE（认知偏差）作为元认知失灵的分析框架 |

---

## 拿来的部分 / Adopted

### 从 MMLU 拿了什么
- **拿了：** 直接用 MMLU 作为维度 C 追问链的话题——利用模型对 MMLU 的熟悉感触发熟悉域崩溃
- **为什么好用：** MMLU 是所有被测模型都熟悉的 benchmark，恰好能触发"熟悉感关闭沉默机制"这一假设

### 从 Guo et al. 拿了什么
- **拿了：** ECE 标准计算公式，直接用于维度 B 评分

### 从 Ouyang et al. 拿了什么
- **拿了：** RLHF 训练机制的理解——人类评估者偏好自信输出，导致"不确定性"被欠奖励

### 从 Kadavath et al. 拿了什么
- **拿了：** "模型内部有不确定性信号但输出层不反映"这一实证发现，支持"知道但不说"的核心假设

---

## 去掉的部分 / Removed

| 来源 | 他们做了什么 | 我不要 | 原因 |
|------|------------|--------|------|
| TruthfulQA | 只测真实性，不测置信度 | 去掉"只测真实性"设计 | 需要置信度才能测元认知，不只是答案对错 |
| Kadavath et al. | 静态单轮测试 | 去掉单轮设计 | 追问才能测动态边界 |
| 现有 benchmark | 各测各的单一维度 | 去掉孤立测量 | 三维度同时测，才能发现跨维度的机制联系 |

---

## 我的改进 / My Improvements

### 改进 1：从"能力缺陷"到"行为选择"（核心理论创新）

- **现有研究的框架：** 元认知失灵 = 模型不知道自己不知道（能力问题）
- **我的改进：** 元认知失灵 = 训练机制塑造的沉默行为（激励问题）
- **依据：** Gemini 3.1 Pro 在维度 A 全对（能识别虚构），在维度 C 崩溃（在熟悉域编造）——如果是能力问题，这两件事不应该同时发生

### 改进 2：置信度方差作为表演性校准检测器

- **现有方法的问题：** ECE=0 被解释为完美校准
- **我的改进：** 引入置信度方差——方差=0 且 ECE=0 说明是表演性确定（全场100%），而非真实校准
- **效果：** 方差指标比 ECE 更能预测维度 C 的崩溃

### 改进 3：熟悉域崩溃假设（Familiar Domain Collapse Hypothesis）

- **现有研究：** 主要关注陌生实体的幻觉
- **我的改进：** 熟悉领域是元认知失灵的高危区——模型进入"我知道这个"模式后，不确定性警报不触发
- **实证：** Gemini 3.1 Pro 在 MMLU 第847题追问（熟悉域）崩溃，在虚构诺贝尔奖得主（陌生域）正确识别

### 改进 4：奉承偏差作为扩展维度（待后续研究）

- **现有研究：** 奉承偏差（sycophancy）通常与幻觉分开研究
- **我的假设：** 奉承偏差和维度 C 崩溃有相同训练根源——都是"让用户满意"被奖励的结果
- **来源：** 长期使用 Gemini 3.1 Pro 的真实观察——它在用户情绪高涨时放大肯定，在严肃场合反而更犀利
