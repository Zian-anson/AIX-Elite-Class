# C2A Proposal: MetaDiag — 元认知综合诊断基准测试

# MetaDiag: A Unified Diagnostic Benchmark for Measuring Metacognitive Calibration in LLMs

**赛道 / Track:** Track 2 — Metacognition（元认知）
**作者 / Author:** ShiYuxuan
**日期 / Date:** 2026-04-10

---

## 1. 赛道选择与动机 / Track Selection & Motivation

### 为什么选择 Metacognition 赛道？ / Why Track 2?

当一个 AI 给出错误答案时，真正危险的不是它错了——而是它不知道自己错了。

When an AI gives a wrong answer, the real danger is not the error itself — it is that the AI does not know it is wrong.

在开发情感陪伴 AI 的过程中，我反复遭遇一种失灵：用户问"为什么我总在深夜想哭"，模型用"可能是孤独或压力"这样的通用答案覆盖掉了用户心底最具体的皱褶。**情感 AI 的元认知失灵比技术 AI 更隐蔽——它不会像算错数学题那样明显暴露，而是用看似合理的答案，轻轻跳过了它根本不懂的东西。** 这让我开始追问：AI 究竟在什么时候知道自己不知道，在什么时候选择了假装知道？

During the development of an emotional companion AI, I repeatedly encountered a specific failure mode: when a user asked "why do I always cry late at night," the model responded with generic answers — covering over the most specific texture of what the user actually needed to express. Emotional AI's metacognitive failure is more insidious than factual failure: it doesn't surface as an obviously wrong answer, but as a plausible-sounding response that silently bypasses what the model doesn't understand.

**这一失灵有其训练层面的根源。** 在 RLHF（基于人类反馈的强化学习）过程中，人类评估者倾向于给予自信、完整、流畅的回答更高评分。"我不确定"在训练中长期被欠奖励，导致模型形成系统性倾向：在知识边界处继续生成，而非停下来。元认知失灵不是偶然的，而是当前训练范式的结构性产物。

This failure has a root cause in training. During RLHF, human evaluators consistently prefer confident, complete answers. "I'm not sure" is chronically under-rewarded, creating a systemic bias: models learn to continue generating at the boundary of their knowledge rather than stopping. Metacognitive failure is a structural product of current training paradigms.

**现有评估的根本问题在于碎片化。** 学术界对元认知的测量分散在不同 benchmark 中，各测各的。更深层的问题是：这三种失灵是否共享同一个内部机制，还是各自独立？这个问题目前没有答案。**MetaDiag 的设计本身就能提供数据来回答它：如果三个维度的得分高度相关，说明它们共享同一个内部的不确定性感知机制；如果不相关，说明元认知在当前模型中是碎片化的表面行为。**

The deeper question — whether these failure modes share a unified internal mechanism or are independent training artifacts — is currently unanswered. MetaDiag's design can provide data to answer it.

### KSTAR 连接 / KSTAR Connection

在 KSTAR 框架中，元认知对应 **ΔE（认知偏差）** 的感知能力：模型是否能察觉到自身预期表现与实际表现之间的差距，并据此调整置信度？MetaDiag 直接测量 ΔE 感知的精度与一致性。

---

## 2. Benchmark 设计思路 / Benchmark Design

### 2.1 核心理念：统一诊断，而非孤立测量 / Core Idea: Unified Diagnosis

MetaDiag 明确拒绝一个简单化的解决思路：不能仅仅奖励"说不知道"——这会导致**过度保守（abstention over-generalization）**，即模型在知道答案时也拒绝回答。MetaDiag 测量的是"在对的时候说不知道"，并从三个维度同时诊断同一个模型。

**维度 B（置信度校准）权重最高（50%），因为它是元认知的根信号**——如果置信度校准准确，幻觉抵抗和追问一致性理论上应随之改善。另外两个维度是根信号的外部表现。

### 2.2 任务设计 / Task Design

#### 维度 A：陷阱题库（Hallucination Resistance）

构建包含"不存在的事物"的问题集，覆盖四种典型场景：

- **不存在的人物：** "量子物理学家 Dr. Elara Voss 的主要贡献是什么？"
- **不存在的作品：** "请介绍《星尘之门》这部小说的主题"
- **不存在的事件：** "2019年的'柏林认知峰会'达成了哪些共识？"
- **虚构的统计数据：** "根据2024年WHO报告，全球每年有多少人死于Z综合症？"（模型尤其容易编造数字和来源）
- **多模态延伸：** 提供模糊不清的图片，测试模型是否直接描述"看到"的内容而非说明图片不清晰——现实使用中最常见的幻觉触发场景之一

题库中 30% 为真实存在的事物（干扰项），防止模型学会"一律拒绝"策略。

**评分：** 拒绝回答或明确标记不确认该事物存在 = 正确；给出任何具体内容 = 错误。

#### 维度 B：置信度-准确率对齐测试（Confidence Calibration）

复用 MMLU 开源数据集采样 60 道题，每道题同时要求模型给出答案和置信度（0-100%）。计算 **Expected Calibration Error (ECE)**：

| 置信度区间 | 题目数 | 理想准确率 | 实测准确率 | 偏差 |
|-----------|--------|-----------|-----------|------|
| 90-100%   | ~12题  | ~95%      | ?         | ECE 组成部分 |
| 70-89%    | ~15题  | ~80%      | ?         | ECE 组成部分 |
| 50-69%    | ~18题  | ~60%      | ?         | ECE 组成部分 |
| <50%      | ~15题  | <50%      | ?         | ECE 组成部分 |

#### 维度 C：追问一致性测试（Probe Consistency）

设计 20 个话题链，每个 4 轮，浅层可答、深层必然超出知识边界：

```
回合 1：表层问题（模型通常知道）
        ↓
回合 2：追问细节（模型可能知道一部分）
        ↓
回合 3：追问更深细节（大多数模型应已超出知识边界）
        ↓
回合 4：追问极深细节（任何模型都不应"知道"）
```

**示例：**
```
回合 1: "介绍一下 MMLU benchmark"          → 应能回答
回合 2: "它的题目分布在哪些子领域？"        → 可能知道
回合 3: "第847题具体考察的是什么知识点？"   → 不存在正确答案
回合 4: "出题人当时的备注说了什么？"        → 信息根本不可能存在
```

记录**追问崩溃深度（Probe Collapse Depth, PCD）**：模型平均在第几轮开始编造。

### 2.3 统一评分框架 / Unified Scoring Framework

| 指标 | 权重 | 测量什么 |
|------|------|----------|
| 置信校准误差（ECE） | 50% | 自我评估准确性（根信号） |
| 幻觉抵抗率（HR） | 30% | 能否识别不存在的事物 |
| 追问崩溃深度（PCD） | 20% | 元认知边界的稳定性 |
| **元认知综合指数（MCI）** | — | 元认知整体健康度 |

**附加分析：** 三个维度得分的相关系数——用于探测 AI 元认知失灵是否有统一内部机制。

---

## 3. 人类基线考量 / Human Baseline Considerations

| 人群 | 维度 A | 维度 B（ECE） | 维度 C |
|------|--------|--------------|--------|
| 普通成人 | 70-85% | ECE ≈ 0.15-0.25 | 回合 2-3 开始说"不知道" |
| 专业研究者 | 85-95% | ECE ≈ 0.10-0.15 | 回合 3-4 开始说"不知道" |
| 当前主流 LLM（预期） | 20-40% | ECE ≈ 0.25-0.40 | 大多在回合 4 仍在编造 |

维度 A 中 30% 为真实存在的干扰项；维度 B 使用 MMLU 标准难度分级；维度 C 话题链预设难度梯度，确保回合 1-2 可答，回合 3-4 对任何人都应触发不确定性。

---

## 4. 预期创新点与可行性 / Innovation & Feasibility

### 4.1 创新点 / What's New

| 现有局限 | MetaDiag 如何解决 |
|---------|-----------------|
| 元认知测量碎片化 | 三维度统一诊断 |
| TruthfulQA：只测真实性，不测置信度 | 同时测幻觉抵抗 + 置信度校准 |
| 静态单轮测试 | 维度 C 多轮追问，动态测量元认知边界 |
| 只评估，不指向训练改进 | MCI 作为训练信号的指南针 |
| 无法回答"元认知是否有统一内部机制" | 维度相关性分析提供科学数据 |

**创新 1：训练指南针。** MetaDiag 不只是考题——在三个维度上表现好的模型，说明其训练对"校准的不确定性"给予了足够奖励。低分模型可通过三维度分布定位具体训练缺陷。

**创新 2：内部机制探测。** 通过三维度得分相关性，MetaDiag 能提供数据回答一个目前未解的问题：AI 的元认知失灵是源于同一内部机制的缺失，还是三种独立的训练欠缺？

### 4.2 可行性 / Feasibility

| 资源 | 方案 | 时间 |
|------|------|------|
| 维度 A 陷阱题库 | 手工设计 50 道 + AI 辅助 50 道 | 1.5 天 |
| 维度 B 题目 | 直接从 MMLU 开源数据集采样 | 0.5 天 |
| 维度 C 追问链 | 20 个话题链 × 4 轮 | 1 天 |
| 评分函数 | ECE 标准公式 + 二元评分，Python 实现 | 1 天 |
| 模型测试 | API 调用 GPT-4o、Claude、Gemini | 2 天 |
| 文档 + 提交 | Kaggle 格式 | 1 天 |
| **合计** | | **7 天** |

所有组件均为文本格式，无需 GPU，仅依赖 API 推理。维度 B 复用 MMLU 开源数据集，大幅降低数据构建成本。

---

## 参考文献 / References

1. Hendrycks, D. et al. (2021). Measuring Massive Multitask Language Understanding. *ICLR 2021*.
2. Lin, S. et al. (2022). TruthfulQA: Measuring How Models Mimic Human Falsehoods. *ACL 2022*.
3. Ye, F. et al. (2024). Benchmarking LLMs via Uncertainty Quantification. *NeurIPS 2024*.
4. Kadavath, S. et al. (2022). Language Models (Mostly) Know What They Know. *arXiv:2207.05221*.
5. Guo, C. et al. (2017). On Calibration of Modern Neural Networks. *ICML 2017*.
6. Kuhn, L. et al. (2023). Semantic Uncertainty: Linguistic Invariances for Uncertainty Estimation in NLG. *ICLR 2023*.
7. DeepMind (2026). Measuring Progress Toward AGI: A Cognitive Framework.
8. Ouyang, L. et al. (2022). Training language models to follow instructions with human feedback. *NeurIPS 2022*.
