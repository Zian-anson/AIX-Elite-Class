# C8_L1_AI日志 — AI+X Elite Class Challenge

## 基本信息

| 字段 | 内容 |
|------|------|
| **学生** | 牛保康 |
| **挑战** | C8 WeChat Class Management |
| **级别** | Level 1 Bronze |
| **日期** | 2026-04-13 |
| **AI 助手** | Hermes (CLI Agent) |
| **模型** | MiniMax-M2.7 |

---

## 问题与解决方案日志

### 问题 1: wechat-cli 的 GBK 编码崩溃

**现象**：
```
UnicodeEncodeError: 'gbk' codec can't encode character '\U0001f389'
```

**原因**：wechat-cli 的 `output/formatter.py` 写 JSON 到 stdout 时没有处理 Windows GBK 控制台编码问题。消息中包含 emoji（🎉）时触发。

**尝试的解决路径**：
1. `chcp 65001` → 无效（设置只在当前 cmd 会话有效）
2. PowerShell pipe `Out-File -Encoding utf8` → 无效（Python 进程的 stdout 已打开）
3. `PYTHONIOENCODING=utf-8` 环境变量 → **有效！**

**最终方案**：
```cmd
set PYTHONIOENCODING=utf-8
wechat-cli history "AI+X Elite Class" --limit 50 --format json
```

同时 patch 了 formatter.py 的 `output_json()` 函数，添加 `file.reconfigure(encoding='utf-8')` 做兜底。

---

### 问题 2: npm 版本的 wechat-cli 需要 Linux 二进制

**现象**：
```
Error: Cannot find module '@canghe_ai/wechat-cli-linux-x64/package.json'
```

**原因**：npm 全局安装的 `@canghe_ai/wechat-cli` 是 Node.js 包装器，它尝试加载平台二进制。在 Windows 上没有 `@canghe_ai/wechat-cli-win32-x64`，只有 macOS ARM64 二进制包。

**解决方案**：卸载 npm 版本，改用 pip 安装纯 Python 包：
```cmd
pip install git+https://github.com/freestylefly/wechat-cli.git
```

---

### 问题 3: pip 代理导致的 JSON 截断

**现象**：
```
UnicodeDecodeError: 'gbk' codec can't encode...
pip install: <HTML> truncated response (proxy)
```

**原因**：Clash 7897 代理偶尔返回截断的响应，pip 解析损坏的 JSON。

**解决方案**：代理本身工作，但不稳定。重试后成功。

---

## 架构决策

### 为什么用 JSONL 而不是 JSON？

- **流式友好**：LLM 可以逐行解析，不必等整个文件加载
- **Append 友好**：新增消息直接 `>>` 追加，无需重写整个文件
- **可观测**：每行独立，调试简单

### 为什么不用 XML/CSV？

- 微信消息含换行符和特殊字符，XML/CSV 转义复杂
- JSON 语义更贴近 Python dict，LLM 理解成本低

---

## 数据样例

### 原始 wechat-cli 输出（简化）

```json
{
  "chat": "AI+X Elite Class",
  "username": "52461657086@chatroom",
  "is_group": true,
  "count": 50,
  "messages": [
    "[2026-04-13 04:33] Richard: [链接/文件] 当前微信版本不支持展示该内容...",
    "[2026-04-13 06:49] me: #接龙 例 Name - Github ID - Number of repos...",
    "[2026-04-13 07:41] dao: [链接/文件] #接龙 ..."
  ]
}
```

### 标准化 JSONL 输出

```jsonl
{"msg_id":0,"timestamp":1744567380,"datetime":"2026-04-13 04:33","sender":"Richard","sender_wxid":"","content":"[链接/文件] 当前微信版本不支持展示该内容，请升级至最新版本。","msg_type":"file","is_group":true,"group_name":"AI+X Elite Class","group_id":"52461657086@chatroom"}
{"msg_id":0,"timestamp":1744574940,"datetime":"2026-04-13 06:49","sender":"me","sender_wxid":"","content":"#接龙 例 Name - Github ID - Number of repos 1. Richard...","msg_type":"text","is_group":true,"group_name":"AI+X Elite Class","group_id":"52461657086@chatroom"}
```

---

## 文件清单

| 文件 | 说明 |
|------|------|
| `wechat_bridge.py` | CLI 桥接脚本，封装 wechat-cli 调用和格式转换 |
| `sample_output.jsonl` | 46 条真实消息样本（已脱敏处理） |
| `SETUP.md` | 完整安装配置文档 |
| `LENOVO_C8_L1_AI日志.md` | 本文件 |

---

## AI 协作反思

### 什么进展顺利？
- Hermes 能够跨 WSL/Windows 边界调用命令，架构清晰
- wechat-cli init 自动检测微信数据库路径，一次成功
- JSONL 格式验证了 LLM 可直接消费

### 什么花了比预期更长的时间？
- Windows 中文编码问题比预想的顽固（GBK/UTF-8 混用）
- npm vs pip 版本混淆（两个包管理器，两套二进制）
- WSL `/mnt/c/` 路径写入出现 UTF-16LE 损坏（根本原因未完全明确）

### 如果重做，会改变什么？
- 直接在 Windows 原生环境（PowerShell）跑命令，跳过 WSL 路径层
- 一开始就用 `PYTHONIOENCODING=utf-8`，不等崩溃再修

---

## 交付物验证

```bash
# 验证 wechat-cli 可用
wechat-cli sessions

# 验证 bridge 可用
python wechat_bridge.py --sessions

# 生成 JSONL
python wechat_bridge.py --group "AI+X Elite Class" --limit 50 --output messages.jsonl

# 检查输出
wc -l messages.jsonl
head -3 messages.jsonl | python -m json.tool
```
