#!/usr/bin/env python3
"""
wechat_bridge.py — Challenge C8 Level 1: 数据桥接

用法:
  python wechat_bridge.py --sessions                              # 列出所有会话
  python wechat_bridge.py --group "AI+X Elite Class" --limit 50  # 拉取消息
  python wechat_bridge.py --group "AI+X Elite Class" --days 7    # 最近7天消息
  python wechat_bridge.py --group "AI+X Elite Class" --type text # 只拉文本消息

环境要求:
  - Windows + 微信客户端运行中
  - wechat-cli 已安装 (pip install wechat-cli)
  - 需要设置 PYTHONIOENCODING=utf-8

输出格式: JSONL (一行一条消息)
每行 JSON Schema:
  {
    "msg_id": int,
    "timestamp": int,
    "datetime": "YYYY-MM-DD HH:mm",
    "sender": str,
    "sender_wxid": str,
    "content": str,
    "msg_type": "text"|"image"|"voice"|"video"|"file"|"link",
    "is_group": true,
    "group_name": str,
    "group_id": str
  }
"""

import argparse
import json
import re
import subprocess
import sys
import os
from datetime import datetime

# Windows path to wechat-cli (installed via pip)
WECHAT_CLI = "wechat-cli"

def run_wechat(args_str, timeout=60):
    """通过 cmd.exe 运行 wechat-cli，返回 stdout"""
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    cmd = f'cmd.exe /c "set PYTHONIOENCODING=utf-8&& {WECHAT_CLI} {args_str}"'
    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=True,
        text=True,
        encoding='utf-8',
        errors='replace',
        timeout=timeout,
        env=env
    )
    if result.returncode != 0:
        print(f"[ERROR] wechat-cli: {result.stderr.strip()}", file=sys.stderr)
        return None
    return result.stdout

def list_sessions():
    """列出所有微信会话"""
    output = run_wechat("sessions --format json")
    if not output:
        return []
    try:
        # 跳过 WSL 前缀，找到 JSON 数组开始
        start = output.find('[')
        if start >= 0:
            return json.loads(output[start:])
    except json.JSONDecodeError as e:
        print(f"[ERROR] JSON parse failed: {e}", file=sys.stderr)
    return []

def fetch_history(chat_name, limit=100, days=None, msg_type=None):
    """
    获取指定聊天记录并转成标准格式
    """
    args = f'history "{chat_name}" --limit {limit} --format json'
    if days:
        args += f' --days {days}'
    if msg_type:
        args += f' --type {msg_type}'

    output = run_wechat(args)
    if not output:
        return [], "", ""

    try:
        start = output.find('{')
        if start >= 0:
            data = json.loads(output[start:])
            records = transform_messages(data)
            return records, data.get("chat", ""), data.get("username", "")
    except json.JSONDecodeError as e:
        print(f"[ERROR] JSON parse failed: {e}", file=sys.stderr)

    return [], "", ""

def transform_messages(data):
    """把 wechat-cli 原始格式转成标准 JSONL 格式"""
    messages = data.get("messages", [])
    results = []

    for msg in messages:
        raw = msg if isinstance(msg, str) else str(msg)
        parsed = parse_raw_message(raw)
        if not parsed:
            continue

        results.append({
            "msg_id": 0,  # wechat-cli 不提供 msg_id
            "timestamp": parsed["ts"],
            "datetime": parsed["datetime"],
            "sender": parsed["sender"],
            "sender_wxid": "",
            "content": parsed["content"],
            "msg_type": infer_msg_type(parsed["content"]),
            "is_group": True,
            "group_name": "",
            "group_id": ""
        })

    return results

def parse_raw_message(raw):
    """
    解析原始消息 '[YYYY-MM-DD HH:mm] sender: content'
    返回 dict 或 None
    """
    # 群消息格式: [2026-04-13 04:33] sender: content
    m = re.match(r'\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2})\] ([^:]+?): (.+)', raw, re.DOTALL)
    if m:
        dt = datetime.strptime(m.group(1), "%Y-%m-%d %H:%M")
        return {
            "datetime": m.group(1),
            "ts": int(dt.timestamp()),
            "sender": m.group(2).strip(),
            "content": m.group(3).strip()
        }

    # 系统消息格式: [2026-04-13 04:33] content
    m = re.match(r'\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2})\] (.+)', raw)
    if m:
        dt = datetime.strptime(m.group(1), "%Y-%m-%d %H:%M")
        return {
            "datetime": m.group(1),
            "ts": int(dt.timestamp()),
            "sender": "[System]",
            "content": m.group(2).strip()
        }

    return None

def infer_msg_type(content):
    """根据内容推断消息类型"""
    if '[链接/文件]' in content: return "file"
    if '[图片]' in content:     return "image"
    if '[语音]' in content:     return "voice"
    if '[视频]' in content:     return "video"
    if content.startswith('http://') or content.startswith('https://'):
        return "link"
    return "text"

def to_jsonl(records, group_name, group_id):
    """把 records 列表转成带 group 元数据的 JSONL 行"""
    lines = []
    for r in records:
        r["group_name"] = group_name
        r["group_id"] = group_id
        lines.append(json.dumps(r, ensure_ascii=False))
    return '\n'.join(lines)

def print_sessions(sessions):
    """友好打印会话列表"""
    print(f"{'Chat Name':<30} {'Type':<6} {'Unread':<8} {'Last Msg':<20}")
    print("-" * 70)
    for s in sessions[:20]:
        unread = s.get("unread", 0)
        last = str(s.get("last_message", ""))[:18].replace('\n', ' ')
        print(f"{s.get('chat', ''):<30} {'Group' if s.get('is_group') else 'P2P':<6} {unread:<8} {last}")

def main():
    parser = argparse.ArgumentParser(
        description="WeChat Bridge — 微信群消息转标准 JSONL (LLM Friendly)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python wechat_bridge.py --sessions
  python wechat_bridge.py --group "AI+X Elite Class" --limit 100
  python wechat_bridge.py --group "AI+X Elite Class" --days 7 --output msgs.jsonl
  python wechat_bridge.py --group "AI+X Elite Class" --type text --limit 200
        """
    )
    parser.add_argument("--sessions", action="store_true", help="列出所有会话")
    parser.add_argument("--group", type=str, help="群名称（包含空格需引号）或 username")
    parser.add_argument("--days", type=int, default=7, help="拉取最近N天消息 (default: 7)")
    parser.add_argument("--limit", type=int, default=100, help="最多消息条数 (default: 100)")
    parser.add_argument("--type", type=str,
                        choices=["text","image","voice","video","file","link"],
                        help="过滤消息类型")
    parser.add_argument("--output", type=str, default="messages.jsonl",
                        help="输出文件 (default: messages.jsonl)")

    args = parser.parse_args()

    if args.sessions:
        print("Fetching sessions...", file=sys.stderr)
        sessions = list_sessions()
        if not sessions:
            print("No sessions found.", file=sys.stderr)
            sys.exit(1)
        print_sessions(sessions)
        return

    if not args.group:
        print("Error: --group required (use --sessions to list available chats)", file=sys.stderr)
        sys.exit(1)

    print(f"Fetching from '{args.group}' (limit={args.limit}, days={args.days})...", file=sys.stderr)
    records, group_name, group_id = fetch_history(args.group, limit=args.limit,
                                                   days=args.days, msg_type=args.type)

    if not records:
        print("No messages retrieved. Is the group name correct?", file=sys.stderr)
        sys.exit(1)

    jsonl_output = to_jsonl(records, group_name, group_id)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(jsonl_output + '\n')
        print(f"OK: {len(records)} messages -> {args.output}", file=sys.stderr)
    else:
        print(jsonl_output)

if __name__ == "__main__":
    main()
