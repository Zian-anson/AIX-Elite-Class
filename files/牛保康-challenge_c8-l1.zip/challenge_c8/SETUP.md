# Challenge C8 Level 1 — 环境配置指南

## 前提条件

- Windows 10/11 + WSL2 (Ubuntu 24.04)
- 微信桌面版运行中
- Python 3.10+ (本项目使用 Hermes Agent 内置 venv)
- 网络可访问 GitHub

---

## Step 1: 安装 wechat-cli

### 方式 A: 通过 pip 安装（推荐）

```bash
# 在 Windows cmd 或 PowerShell 中运行
pip install wechat-cli
```

### 方式 B: 通过 pip 从 GitHub 直接安装

```bash
pip install git+https://github.com/freestylefly/wechat-cli.git
```

### 验证安装

```bash
wechat-cli --version
```

---

## Step 2: 初始化（首次使用必须）

**重要：先打开微信桌面版，再运行初始化**

```bash
wechat-cli init
```

成功后会看到：
```
[+] 检测到微信数据库目录: C:\Users\你的用户名\OneDrive\xwechat_files\wxid_xxx\db_storage
[+] 找到 N 个数据库, N 个解密 salt
[+] 提取到 N/N 解密密钥
密钥保存到: C:\Users\你的用户名/.wechat-cli/all_keys.json
```

---

## Step 3: 查询会话列表

```bash
wechat-cli sessions
```

输出示例：
```
Chat Name                       Type   Unread   Last Msg
----------------------------------------------------------------------
AI+X Elite Class                Group  0        #接龙 例 Name - Github ID...
微信团队                         P2P    50       [链接/文件] 请升级至最新版本
```

---

## Step 4: 拉取群消息

### 基本用法

```bash
# 方式 1: 直接用群名（中文需要引号）
wechat-cli history "AI+X Elite Class" --limit 100

# 方式 2: 用 chatroom username（从 sessions 输出获取）
wechat-cli history 52461657086@chatroom --limit 100

# 方式 3: 只拉文本消息
wechat-cli history "AI+X Elite Class" --limit 100 --type text
```

### 过滤消息类型

| 类型   | 命令参数        |
|--------|----------------|
| 文本   | `--type text`  |
| 图片   | `--type image` |
| 语音   | `--type voice` |
| 视频   | `--type video` |
| 文件   | `--type file`  |
| 链接   | `--type link`  |

### 限制日期范围

```bash
# 最近 7 天
wechat-cli history "AI+X Elite Class" --days 7

# 指定日期范围
wechat-cli history "AI+X Elite Class" --start-time "2026-04-01" --end-time "2026-04-13"
```

---

## Step 5: 用 wechat_bridge.py 输出标准 JSONL

`wechat_bridge.py` 是本 Challenge 的交付物之一，把 wechat-cli 输出转成 LLM 友好的 JSONL 格式。

```bash
# 列出所有会话
python wechat_bridge.py --sessions

# 拉取并转换
python wechat_bridge.py --group "AI+X Elite Class" --limit 100 --output messages.jsonl
```

### JSONL 输出格式

每行一条消息，JSON Schema:
```json
{
  "msg_id": 0,
  "timestamp": 1744567800,
  "datetime": "2026-04-13 07:41",
  "sender": "dao",
  "sender_wxid": "",
  "content": "#接龙 例 Name - Github ID - Number of repos\n1. Richard...",
  "msg_type": "text",
  "is_group": true,
  "group_name": "AI+X Elite Class",
  "group_id": "52461657086@chatroom"
}
```

---

## 常见问题

### Q: `wechat-cli init` 失败
**A**: 确保微信已打开，且 Windows 用户名不包含中文空格

### Q: `UnicodeEncodeError: 'gbk' codec can't encode character`
**A**: 运行时设置环境变量
```cmd
set PYTHONIOENCODING=utf-8
wechat-cli history "群名" --format json
```

### Q: 找不到群
**A**: 用 `wechat-cli sessions` 查看正确的群名（注意空格和标点）

### Q: Linux/macOS 用户
**A**: wechat-cli 支持 macOS ARM64 (npm) 和 Linux (需要 root 读取 /proc)。Windows 是最完整的实现。

---

## 目录结构

```
~/.wechat-cli/
├── all_keys.json    # 解密密钥（重要！不要分享）
└── config.json      # 配置信息

你的项目目录/
├── wechat_bridge.py        # CLI 桥接脚本
├── sample_output.jsonl     # 示例输出
├── SETUP.md                # 本文档
└── 姓名_C8_L1_AI日志.md    # AI 协作日志
```

---

## 数据安全

- 解密密钥存储在 `~/.wechat-cli/`，不要上传到 GitHub
- 导出的 JSONL 文件包含聊天内容，上传前注意脱敏
- 本工具仅供个人本地数据查询使用
