# ATTRIBUTION.md — C5-AG2 Submission by &lt;Your Name&gt;

> Elite20 拿来主义 (fork-and-improve) principle: every reused fragment is cited.
> 每一处借鉴都要溯源。

---

## 1. Fork source / Fork 源

| | |
|---|---|
| Base project | &lt;Project name from `samples/submitted_repos.md`&gt; |
| Base repo URL | &lt;https://github.com/...&gt; |
| Base captain | &lt;name&gt; |
| My fork URL | &lt;your repo&gt; |
| Fork commit SHA at fork time | &lt;sha&gt; |
| Track inheritance | base `scientific` / `multi-agent` / `open` → mine: same / changed to ___ |

If you started **from scratch**, replace this section with:

> "Did not fork an existing repo. Drew architectural inspiration from: &lt;list 1–3 catalog projects&gt;."

---

## 2. AG2 documentation references / AG2 文档引用

> 每一段从 AG2 文档复制/改编的代码必须注明来源。
> Every code block copied or adapted from AG2 docs must cite its source file.

| File in your repo | Lines | Source doc | Verbatim / Adapted |
|-------------------|-------|------------|--------------------|
| `agents/greeter.py` | 1–35 | `references/ag2_docs/20_beta_example_hello_agent.mdx` | adapted: changed model + prompt |
| `agents/research_squad.py` | 1–80 | `references/ag2_docs/21_beta_example_research_squad.mdx` | adapted: replaced 2 of the 4 agents with my own |
| `tools/web_search.py` | 12–40 | `references/ag2_docs/30_beta_tools_builtin.mdx` (`web_search` snippet) | verbatim with type-hint changes |
| `runtime/sandbox.py` | all | `references/ag2_docs/03_beta_data_analyst.md` (Daytona pattern) | adapted: minor refactor |

---

## 3. Code reused from sample repos / 借鉴自样本 repo

| Source repo | Source file | Used in my repo | Notes |
|-------------|-------------|-----------------|-------|
| Mycelium ([Shaivpidadi/Mycelium](https://github.com/Shaivpidadi/Mycelium)) | `agents/cto.py` | `agents/architect.py` | Reused "decompose-then-route" pattern. Renamed roles. |
| build-with-ag2/beta/data-analyst | `runner.py` | `sandbox/runner.py` | Reused Daytona session bootstrap; replaced sample data with mine. |
| _(add more)_ | | | |

---

## 4. Prompts and prompt fragments / 提示词与提示词片段

| Used in | Source | Verbatim / Adapted |
|---------|--------|--------------------|
| `prompts/synthesizer.txt` | Anthropic prompt-eng cookbook (cite URL) | adapted |
| `prompts/critic.txt` | original (mine) | — |

---

## 5. Datasets, assets, and other inputs / 数据集与其它输入

| Asset | Source | License |
|-------|--------|---------|
| `data/sample_papers.json` | arXiv abstracts (CC0) | CC0 |
| `assets/logo.svg` | Made with v0 by Vercel | usage rights — verify |

---

## 6. What I added / created / 我新增的部分

> 必须有这一节。否则不算"改造"，只是"复制"。
> Required section. Without it, this is a copy, not a refactor.

- &lt;Component A&gt;: described in 1–3 sentences. Lines &lt;file:lines&gt;.
- &lt;Component B&gt;: ...
- &lt;Component C&gt;: ...

---

## 7. License compatibility check / 许可证兼容性检查

| Source | Source license | Compatible with my license? |
|--------|---------------|----------------------------|
| Base repo (Mycelium) | MIT | ✅ My repo: MIT |
| build-with-ag2/* | Apache 2.0 | ✅ |
| AG2 framework | Apache 2.0 | ✅ |

---

## 8. Self-audit / 自审

- [ ] Every code block ≥ 5 lines copied from elsewhere is cited above
- [ ] My fork source is identified (or "from scratch" declared explicitly)
- [ ] License compatibility checked
- [ ] Section 6 ("What I added") is non-trivial (≥ 3 substantive items)
