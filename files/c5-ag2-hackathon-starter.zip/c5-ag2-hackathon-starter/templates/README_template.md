# &lt;Project name&gt;

&lt;One-line tagline. ≤ 60 characters. — same one you'll put on the hackathon submission form.&gt;

**Track:** `scientific` / `multi-agent` / `open`
**Base / fork source:** &lt;name + URL, or "from scratch"&gt;
**AG2 version:** `ag2 ==X.Y.Z` (Beta · `autogen.beta`)

---

## What it is / 一句话定位

**Input:** &lt;____&gt;
**Output:** &lt;____&gt;

&lt;Two paragraphs describing the problem and your approach. Mention the multi-agent shape: which agents, who delegates to whom, what's the handoff signal.&gt;

---

## 5-minute setup / 5 分钟跑起来

```bash
# 1. clone
git clone <your repo url>
cd <repo>

# 2. python env
python -m venv .venv && source .venv/bin/activate    # Python 3.10–3.13
pip install -r requirements.txt

# 3. set keys
cp .env.example .env
# edit .env to set OPENROUTER_API_KEY (or OPENAI_API_KEY) and TAVILY_API_KEY

# 4. run
python -m <your.entrypoint>
```

Expected first-run output:

```
<paste 5–15 lines of expected output so users know it's working>
```

If you see an error, check the troubleshooting section at the bottom.

---

## Multi-agent design / 多 agent 架构

```
+--------+      delegate       +-----------+
| Lead   | ------------------> | Researcher|
| Agent  |                     +-----------+
|        |      delegate       +-----------+
|        | ------------------> | Critic    |
+--------+                     +-----------+
   ^                                |
   |  reply                         | reply
   +--------------------------------+
```

| Agent | Role | Model | Tools | Source |
|-------|------|-------|-------|--------|
| Lead | Decomposes task, routes, integrates | `gemini-3-flash-preview` | (none) | mine |
| Researcher | Web research + synthesis | `gemini-3-flash-preview` | `web_search` (Tavily) | adapted from `references/ag2_docs/21_beta_example_research_squad.mdx` |
| Critic | Adversarial review of researcher output | `gemini-3-flash-preview` | (none) | mine |

---

## Live demo / 现场演示

- **Demo URL:** &lt;hosted link or "local only"&gt;
- **Video:** &lt;Loom / YouTube link&gt;  *(60–90 s; for Loom, "Anyone with the link" must be enabled)*
- **Thumbnail:** &lt;optional&gt;

---

## Project structure / 项目结构

```
<repo>/
├── README.md                # this file
├── AI_LOG.md                # AI-First evidence (required)
├── ATTRIBUTION.md           # 拿来主义 evidence (required)
├── LICENSE                  # MIT or Apache 2.0
├── .env.example
├── requirements.txt
├── agents/
│   ├── lead.py
│   ├── researcher.py
│   └── critic.py
├── tools/
│   └── web_search.py
├── prompts/
│   ├── lead.txt
│   ├── researcher.txt
│   └── critic.txt
└── tests/
    └── test_smoke.py
```

---

## Tech stack / 技术栈

- AG2 Beta (`autogen.beta`)
- Python 3.10+
- OpenRouter / Tavily / Daytona (optional)
- &lt;your UI: Streamlit / FastAPI + React / CLI&gt;

---

## Tests

```bash
pytest -q
```

The smoke test mocks all LLM calls (uses `autogen.beta.testing`), so it runs offline in &lt; 5 s.

---

## Troubleshooting / 常见问题

- **`ModuleNotFoundError: No module named 'autogen.beta'`** — make sure you `pip install ag2` (the beta module ships with the main package).
- **`401` from OpenRouter** — check that your `OPENROUTER_API_KEY` matches the one issued at the event dashboard; regenerate if needed.
- **Loom video reports "you don't have access"** — the Loom owner must turn on "Anyone with the link can view" before judging.

---

## License

&lt;MIT or Apache 2.0&gt;. See `LICENSE`.

## Acknowledgements

- AG2 team (Qingyun Wu, Vasiliy Radostev, contributors).
- &lt;Base repo author&gt; for the original implementation I forked.
- Elite20 for the C5-AG2 challenge framing.
