# AI_LOG.md — C5-AG2 Submission by &lt;Your Name&gt;

> 本文件记录从 fork 到提交的全部 AI 协作过程。Elite20 AI-First 原则要求：
> 每一步都有 AI 参与，每一处手动步骤都有反向举证。
>
> Tracks every AI-assisted step from fork to submission. Elite20 AI-First principle:
> AI participates in every step; any manual step needs reverse-justification.

---

## Project metadata / 项目信息

| | |
|---|---|
| Repo URL | _(your fork)_ |
| Track | `scientific` / `multi-agent` / `open` |
| Base repo (fork source) | _(from `samples/submitted_repos.md` — name + URL)_ |
| AG2 version used | `ag2 ==X.Y.Z` |
| Beta vs legacy | **Beta** / Legacy |
| Models used | e.g. `google/gemini-3-flash-preview` |
| Sandbox / runtime | Daytona / local / other |

---

## AI tools used / 使用的 AI 工具

| Tool | What for | Approx. tokens / sessions |
|------|----------|---------------------------|
| Claude (Sonnet/Opus) | Architecture + multi-agent prompt design | |
| Cursor / Claude Code | In-editor codegen | |
| ChatGPT (GPT-5) | Code review + debugging | |
| AG2 Beta auto-skills | 15 plug-in skills loaded into editor | |
| Other | | |

---

## Iteration log / 迭代日志

> 至少 5 轮可验证迭代。每轮包含：目标、prompt 摘要、产出、是否采纳、调整原因。
>
> ≥ 5 verifiable iterations. Each entry: goal, prompt summary, output, accepted?, why adjusted.

### Iteration 1 — &lt;date HH:MM&gt; — &lt;goal: e.g. "Bootstrap fork & get hello-agent running"&gt;

- **AI used:** &lt;tool&gt;
- **Prompt summary:** &lt;1–3 sentences describing what you asked&gt;
- **AI output (excerpt):** &lt;paste the key block of generated code or text, ≤ 30 lines&gt;
- **Verification:** &lt;how you verified — e.g. ran `python 01_hello_agent.py`, observed expected output&gt;
- **Adopted?** ✅ / ⚠️ partial / ❌
- **What I changed manually and why:** &lt;e.g. fixed import path; AG2 Beta moved `Agent` from `autogen.beta.agents` to `autogen.beta`&gt;

### Iteration 2 — &lt;goal: e.g. "Replace legacy ConversableAgent with autogen.beta.Agent"&gt;

- **AI used:**
- **Prompt summary:**
- **AI output (excerpt):**
- **Verification:**
- **Adopted?**
- **What I changed manually and why:**

### Iteration 3 — &lt;goal: e.g. "Add second agent — Critic via sub-task delegation"&gt;

- ...

### Iteration 4 — &lt;goal: e.g. "Wire built-in tool: web search via Tavily"&gt;

- ...

### Iteration 5 — &lt;goal: e.g. "README + run-in-5-min check"&gt;

- ...

_(Add Iteration 6, 7, … as needed.)_

---

## Manual steps & their justification / 手动步骤反向举证

| Step | Why manual? | Why AI couldn't / shouldn't do this |
|------|-------------|-------------------------------------|
| Recorded the Loom video | Live screen capture of my own browsing | AI cannot drive my screen-recorder + my voice |
| Generated my own API keys | Account-bound to my email | Security — AI must not see private keys |
| Final `git push` to my account | Auth bound to my SSH key | (commit messages can still be AI-drafted) |

---

## Self-audit / 自审

- [ ] At least 5 iterations documented
- [ ] Each iteration has a verification step
- [ ] Each manual step has a justification
- [ ] No API keys leaked into this log
- [ ] No private personal info leaked into this log

---

## What I would do differently next time / 下次改进

&lt;Two or three sentences. Useful for your C10 systematization later.&gt;
