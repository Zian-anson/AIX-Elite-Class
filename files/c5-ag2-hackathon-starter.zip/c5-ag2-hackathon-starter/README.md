# C5-AG2 Challenge Starter Package / 挑战启动包

> **Elite20 Challenge 5 — AG2 multi-agent variant.**
> 用 AG2 (formerly AutoGen) 框架构建一个可复现、可演示的 multi-agent GitHub repo。
> Build a reproducible, demo-able multi-agent GitHub repo on the AG2 framework.

---

## 这个包里有什么 / What's in this package

```
c5-ag2-hackathon-starter/
├── CHALLENGE.md                          ← 主规范（先读这个）/ Main spec — read this first
├── README.md                             ← 你现在看的这页 / This page
├── references/
│   ├── ag2_docs/                         ← 24 个 AG2 文档离线缓存 / 24 AG2 docs (offline cache)
│   │   ├── 00_ag2_main_readme.md
│   │   ├── 01_quickstart.mdx
│   │   ├── 02_build_with_ag2_index.md
│   │   ├── 03_beta_data_analyst.md       ← Daytona 沙盒 + 数据分析 agent 示例
│   │   ├── 04_beta_mystery_dinner.md     ← 浏览器渲染的多 agent 示例
│   │   ├── 10_beta_motivation.mdx        ← 必读 / must read
│   │   ├── 11_beta_agents.mdx
│   │   ├── 12_beta_agent_harness.mdx
│   │   ├── 13_beta_task_delegation.mdx   ← 多 agent 模式 1: sub-task delegation
│   │   ├── 14_beta_model_configuration.mdx
│   │   ├── 15_beta_ag2_compatibility.mdx
│   │   ├── 20_beta_example_hello_agent.mdx        ← 最小可运行示例
│   │   ├── 21_beta_example_research_squad.mdx     ← 多 agent 完整示例
│   │   ├── 22_beta_example_recipe_builder.mdx
│   │   ├── 30_beta_tools_builtin.mdx     ← web search / code execution / memory
│   │   ├── 31_beta_tools_code_execution.mdx
│   │   ├── 32_beta_tools_approval.mdx
│   │   ├── 40_beta_inputs.mdx
│   │   ├── 41_beta_structured_output.mdx
│   │   ├── 42_beta_human_in_loop.mdx
│   │   ├── 50_beta_advanced_aggregation.mdx
│   │   ├── 51_beta_advanced_files.mdx
│   │   ├── 52_beta_advanced_knowledge_store.mdx  ← 持久化记忆
│   │   ├── 60_beta_telemetry.mdx
│   │   ├── 61_beta_testing.mdx
│   │   └── docs_groupchat.mdx            ← legacy AG2 GroupChat
│   └── hackathon/
│       ├── hackathon_brief.md            ← 复刻版 hackathon 规则、赛道、奖项
│       └── rubric.yaml                   ← 评分 rubric (机器可读)
├── samples/
│   └── submitted_repos.md                ← 26 个真实 hackathon 提交 + 拿来主义指南
├── templates/
│   ├── README_template.md                ← repo 顶层 README 模板
│   ├── AI_LOG_template.md                ← AI-First 记录模板（必填）
│   ├── ATTRIBUTION_template.md           ← 拿来主义记录模板（必填）
│   ├── env_example.txt                   ← .env 样板
│   └── requirements_example.txt          ← Python 依赖样板
└── examples/
    └── hello_multiagent.py               ← 30 行可运行示例：Lead + Critic
```

---

## 5-step quickstart / 五步上手

```
1.  Read CHALLENGE.md              (~10 min)
2.  Skim references/hackathon/     (~10 min)
3.  Browse samples/submitted_repos.md, pick 1 base repo  (~10 min)
4.  Read references/ag2_docs/10_beta_motivation.mdx and ../20_beta_example_hello_agent.mdx  (~15 min)
5.  Fork → run → add a 2nd agent → record demo → submit  (~4 hours)
```

---

## Two paths / 两条路线

### Path A — 拿来主义 (recommended) / Borrow & improve

> 适合：第一次写 multi-agent；时间紧；想最大化"用别人的肩膀"分。
> Best if: first time with multi-agent; time-pressed; want max 拿来 score.

1. Open `samples/submitted_repos.md`.
2. Pick a base repo by track or by skill goal (decision table at bottom of that file).
3. Fork → clone → run → add your second agent → ship.

### Path B — From scratch / 从零开始

> 适合：想深入学 AG2 Beta 内核；有 4–6 小时；愿意调试。
> Best if: deeper learning; have 4–6 h; willing to debug.

1. Read `references/ag2_docs/10_beta_motivation.mdx` end-to-end.
2. Run `examples/hello_multiagent.py` to verify environment.
3. Pick **one** of the 8 code examples (`20_..` to `27_..`), adapt to your idea.
4. Add at least one of: `web_search`, `code_execution` (Daytona), or `knowledge_store`.
5. Wire AI_LOG.md from the start — don't reconstruct it at submission time.

---

## Submission checklist / 提交清单

```
□ Repo public on GitHub
□ README.md (use templates/README_template.md as scaffold)
□ AI_LOG.md   (≥ 5 verifiable iterations — templates/AI_LOG_template.md)
□ ATTRIBUTION.md (cites fork source + reused snippets — templates/ATTRIBUTION_template.md)
□ LICENSE (MIT or Apache 2.0)
□ .gitignore (no .env, no API keys committed)
□ requirements.txt or pyproject.toml lists `ag2`
□ Main loop imports `autogen.beta` and uses ≥ 2 cooperating agents
□ 60–90 s demo video accessible (Loom: 'Anyone with the link' enabled)
□ Group message posted: link + tagline + track
```

Detailed rubric and Elite20 bonuses → `CHALLENGE.md` §6.

---

## Reference / 参考

- AG2 framework: https://docs.ag2.ai/ · https://github.com/ag2ai/ag2
- AG2 Beta motivation: https://docs.ag2.ai/latest/docs/beta/motivation/
- Build-with-AG2 examples: https://github.com/ag2ai/build-with-ag2
- Original hackathon (live): https://ag2-hackathon.vercel.app/

---

> **C5-AG2 的本质：拿来 → 改造 → 加个 agent → 录视频 → 发布。**
> **Essence of C5-AG2: Borrow → refactor → add an agent → record → ship.**
