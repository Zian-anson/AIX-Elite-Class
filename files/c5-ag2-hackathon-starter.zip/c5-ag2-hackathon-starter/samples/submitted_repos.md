# Sample Repos — AG2 Hackathon Submissions / 样本 Repo + 拿来主义指南

> 来自 2026-05-04 NYC AG2 Hackathon 的全部 26 个真实提交。
> All 26 real submissions from the AG2 Hackathon held in NYC on 2026-05-04.
>
> 每个 repo 都附 **拿来主义指南**——告诉你 _哪个部分值得抄_、_怎么改造_、_最快的 fork 路径_。
> Each repo includes 拿来主义 guidance — _what's worth copying_, _how to adapt_, _shortest fork path_.

---

## 0. 一目了然总表 / At-a-glance index

| # | Project | Track | Score (/25) | Captain | Repo |
|---|---------|-------|-------------|---------|------|
| 1 | **Trading With Alpaca** | multi-agent | 16 | Jilong Chen | [patrickjchen/TradingWithAlpaca](https://github.com/patrickjchen/TradingWithAlpaca) |
| 2 | **Life Sandbox** | multi-agent | 13 | Rui | [myaooo/ag2-hackathon](https://github.com/myaooo/ag2-hackathon) |
| 3 | **FillNinja** | multi-agent | 16 | Alvin | [Xavierhuang/fillninja](https://github.com/Xavierhuang/fillninja) |
| 4 | **Codescan** | multi-agent | — | Meyhar Sharma | [meyharsharma/hackathon-fordham](https://github.com/meyharsharma/hackathon-fordham) |
| 5 | **CreatorCrew** | multi-agent | — | Tali | [shageenthsandrakumar/high-five](https://github.com/shageenthsandrakumar/high-five) |
| 6 | **kalshi-deep-research** | multi-agent | — | Kirill | [gertsio/kalshi-ai-research](https://github.com/gertsio/kalshi-ai-research) |
| 7 | **Mycelium** | multi-agent | — | Shaishav | [Shaivpidadi/Mycelium](https://github.com/Shaivpidadi/Mycelium) |
| 8 | **pest off** | multi-agent | — | Ryan Rana | [RyanRana/ag2-hack](https://github.com/RyanRana/ag2-hack) |
| 9 | **Mesh Shield** | multi-agent | 15 | RS | [roshaninfordham/meshshieldai](https://github.com/roshaninfordham/meshshieldai) |
| 10 | **Verity** | multi-agent | 10 | Advik Bhatt | [advik-bhatt/verity](https://github.com/advik-bhatt/verity) |
| 11 | **Research_paper_synthesizer** | scientific | 6 | kevin | [azhao18/AG2_Hackathon/tree/kevin](https://github.com/azhao18/AG2_Hackathon/tree/kevin) |
| 12 | **RefereeOS** | scientific | — | Vincent DiPaola | [VJDiPaola/RefereeOS](https://github.com/VJDiPaola/RefereeOS) |
| 13 | **ECAG2** | scientific | — | Zackk | [zack1111111111111/ECAG2](https://github.com/zack1111111111111/ECAG2) |
| 14 | **lionag2** | scientific | — | Haiyang Li | [khive-ai/lionag2](https://github.com/khive-ai/lionag2) |
| 15 | **Pippette twin** | scientific | — | Isayah Culbertson | [isayahc/pipetting-twin](https://github.com/isayahc/pipetting-twin) |
| 16 | **SciSift** | scientific | — | Icesummercream | [pandaji/ag2-hackathon](https://github.com/pandaji/ag2-hackathon) |
| 17 | **Summit-Life-Science ResearchOS** | scientific | 18 | Yang Zhang | [ZacharyZhang-NY/SLS-Researcher](https://github.com/ZacharyZhang-NY/SLS-Researcher) |
| 18 | **BioForge** | scientific | 12 | Jian Jin Chen | [JJC3321/BioForge](https://github.com/JJC3321/BioForge) |
| 19 | **Multi-Agent Research Paper Assistant** | scientific | — | Mike wang | [guocity/ag2_event_code](https://github.com/guocity/ag2_event_code) |
| 20 | **Get me Up2Date** | scientific | — | EZ | [0ethel0zhang/ag2_hack/tree/main](https://github.com/0ethel0zhang/ag2_hack/tree/main) |
| 21 | **memo-in-browser-ag2** | open | 17 | Amy | [amlworks/ag2-browser-agent.git](https://github.com/amlworks/ag2-browser-agent.git) |
| 22 | **FutureMe** | unspecified | — | None | [LilChainyy/future-me.git](https://github.com/LilChainyy/future-me.git) |
| 23 | **Money Heist** | unspecified | — | None | [MichaelFehdrau0205/moneyheist.git](https://github.com/MichaelFehdrau0205/moneyheist.git) |
| 24 | **Team Concord'** | unspecified | — | None | [d3v07/AG2_Hackathon](https://github.com/d3v07/AG2_Hackathon) |
| 25 | **SynapSpace AI is an AG2-powered operating system for events.** | unspecified | — | None | [hasanulchow/SynapSpace-AG2-Playground.git](https://github.com/hasanulchow/SynapSpace-AG2-Playground.git) |
| 26 | **Agent Airlock** | unspecified | — | None | [du-song/ag2-test/](https://github.com/du-song/ag2-test/) |

---

## 🤖 Track: multi-agent / 多智能体协作  (10 repos)

### 1. **Trading With Alpaca**
> _trading cryptoes from your browser_

- **Captain / 队长:** Jilong Chen
- **Members / 成员:** jilong.chen@gmail.com (Jilong Chen) [owner]
- **Repo:** https://github.com/patrickjchen/TradingWithAlpaca
- **Video:** https://github.com/patrickjchen/TradingWithAlpaca
- **Total score / 总分:** 16 / 25
- **Sub-scores / 分项:** Innovation & creativity: 4 · Technical execution: 4 · Impact & usefulness: 4 · Use of AG2 / multi-agent design: 4
- **Description:** a trading system to trade on Alpaca market data order management persister to sqlite3 redis for cache /efficieny web GUI to place order/monitor activities

**🪜 拿来主义指南 / Fork & improve guidance:**

- 🧠 **Redis-backed state** — clean horizontal-scaling pattern.
- 🥇 **Top-tier score** — high-fidelity reference; worth full code-walk.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/patrickjchen/TradingWithAlpaca` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 2. **Life Sandbox**
> _Your life, your rules._

- **Captain / 队长:** Rui
- **Members / 成员:** zrubyznyu@gmail.com (Rui) [owner]; yaoming.thu@gmail.com (Yao M.)
- **Repo:** https://github.com/myaooo/ag2-hackathon
- **Live demo:** https://8765-1cz90v7oeps0celu.daytonaproxy01.net/
- **Video:** https://8765-1cz90v7oeps0celu.daytonaproxy01.net/
- **Total score / 总分:** 13 / 25
- **Sub-scores / 分项:** Innovation & creativity: 5 · Technical execution: 3 · Impact & usefulness: 2 · Use of AG2 / multi-agent design: 3
- **Description:** We built a multi-agent life simulator that helps new graduates explore different career paths in parallel. Instead of providing a single recommendation, our system simulates how choices like Big Tech, startups, or consulting evolve over time, highlighting trade-offs across income, risk, and lifestyle. Multiple agents — representing perspectives such as career growth, finance, risk, and life style — evaluate each scenario and interact to shape decisions. This allows users to compare multiple possible futures side by side and better understand the consequences of their choices before committing…

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/myaooo/ag2-hackathon` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 3. **FillNinja**
> _Browser extension using agents find and fill out forms on your behalf_

- **Captain / 队长:** Alvin
- **Members / 成员:** alvinpeng4@gmail.com (Alvin) [owner]; hhuangweijia@gmail.com (Weijia Huang)
- **Repo:** https://github.com/Xavierhuang/fillninja
- **Video:** https://youtu.be/GZZ60TfHhuU
- **Total score / 总分:** 16 / 25
- **Sub-scores / 分项:** Innovation & creativity: 3 · Technical execution: 4 · Impact & usefulness: 5 · Use of AG2 / multi-agent design: 2 · Presentation & demo: 2
- **Judge notes / 评委备注:** Not awed but good useful tool
- **Description:** FillNinja Browser extension (Manifest V3) plus a local FastAPI service with an AG2 multi-agent pipeline: Search Curator — Tavily (live web; free API key) when TAVILY_API_KEY is set, otherwise ddgs (DuckDuckGo), then PromptedSchema(DiscoveryResult) to shortlist real application pages. Override with FILLNINJA_SEARCH=auto|tavily|ddgs. Fill agents (per tab) — planner + optional reviewer, with parallel runs across tabs. Prerequisites Python 3.10+ (3.12 recommended if your environment blocks newer runtimes) Chrome or Chromium An OpenRouter API key (OPENROUTER_API_KEY), or any OpenAI-compatible key…

**🪜 拿来主义指南 / Fork & improve guidance:**

- 🔎 **Live web search via Tavily** — copy the search-curator agent pattern.
- 🌐 **Browser-extension shell** — interesting deployment surface.
- 🛠 **FastAPI backend** — good template for serving multi-agent output.
- 🥇 **Top-tier score** — high-fidelity reference; worth full code-walk.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/Xavierhuang/fillninja` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 4. **Codescan**
> _Turn legacy codebases into easy to read documentation_

- **Captain / 队长:** Meyhar Sharma
- **Members / 成员:** meyharsharma@yahoo.com (Meyhar Sharma) [owner]
- **Repo:** https://github.com/meyharsharma/hackathon-fordham
- **Video:** https://youtu.be/ByRTD0eB-9Y
- **Total score / 总分:** — / 25
- **Description:** What it is Codescan is a documentation generator for legacy codebases. Point it at any git URL and it returns a complete onboarding guide: a dependency map, per-module summaries, the public API with usage examples, archaeology of design decisions mined from git history, and a synthesized markdown field guide. The work is split across five specialist agents, each running as its own OS process on its own port. They coordinate over IBM's NLIP protocol (Ecma-430, ratified December 2025) — a JSON-over-HTTP envelope spec for agent-to-agent communication. The agent runtime inside each process is AG2…

**🪜 拿来主义指南 / Fork & improve guidance:**

- 🛠 **FastAPI backend** — good template for serving multi-agent output.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/meyharsharma/hackathon-fordham` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 5. **CreatorCrew**
> _Find your people. Plan your content. Grow your brand._

- **Captain / 队长:** Tali
- **Members / 成员:** xz5471@nyu.edu (Tali) [owner]
- **Repo:** https://github.com/shageenthsandrakumar/high-five
- **Video:** https://www.youtube.com/shorts/rGhO5FJCog0
- **Total score / 总分:** — / 25
- **Description:** CreatorCrew is a multi-agent AI system designed to help content creators find and connect with the right audience, plan effective content, and grow their brand without guesswork. By simply answering three open-ended questions about who they are, what they want to create, and their goals, creators activate a coordinated team of specialized AI agents that work together to generate a personalized audience profile, content strategy, and ready-to-post content. What makes CreatorCrew unique is its agent collaboration: each agent builds on the output of the previous one, ensuring that every…

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/shageenthsandrakumar/high-five` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 6. **kalshi-deep-research**
> _kalshi-deep-research_

- **Captain / 队长:** Kirill
- **Members / 成员:** gertsdev@gmail.com (Kirill) [owner]; alina10.1179@icloud.com (Alina Boldyrieva)
- **Repo:** https://github.com/gertsio/kalshi-ai-research
- **Video:** https://www.loom.com/share/5b587dd0de6644eeaea2b5bb4c281edf
- **Total score / 总分:** — / 25
- **Description:** Research-only prediction-market analysis for Kalshi markets, powered by a typed Next.js frontend and a separate Python workflow runtime. Kalshi Research Swarm compares Kalshi's market-implied probability with an agent-generated estimate, then frames the difference with evidence, counterarguments, settlement risks, warnings, and a concise memo. It is built as a hackathon-friendly prototype with strict contracts and deterministic demo behavior.

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/gertsio/kalshi-ai-research` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 7. **Mycelium**
> _An AI software studio where C-suite leads hire and fire specialists per task each gets its own Daytona sandbox and git worktree_

- **Captain / 队长:** Shaishav
- **Members / 成员:** shaivpidadi@gmail.com (Shaishav) [owner]
- **Repo:** https://github.com/Shaivpidadi/Mycelium
- **Video:** https://www.loom.com/share/82e6a9e37dc9439b966a3b4f4caf5a3d
- **Total score / 总分:** — / 25
- **Sub-scores / 分项:** Innovation & creativity: 3 · Technical execution: 4 · Impact & usefulness: 4 · Use of AG2 / multi-agent design: 4 · Presentation & demo: 4
- **Description:** Mycelium is a multi-agent SDLC. You give it one investor direction. Five hand-written autogen.beta.Agent leads — CEO, CTO, UI Lead, QA Lead, Tech Lead — decompose, route, review, and ship. The engineers, UI engineers, and testers that actually do the work don't exist when you start typing. They are spawned at runtime by the leads' tools, each given its own Daytona sandbox and a git worktree on a fresh feat/* branch. How it works DIRECTION ──► CEO ──► CTO ──► spawn_engineer(name, brief, files) │ │ ▼ Daytona sandbox + git worktree on feat/<task> │ │ engineer commits to its own branch │ ▼ │…

**🪜 拿来主义指南 / Fork & improve guidance:**

- ✅ **Uses AG2 Beta.** Worth studying its `autogen.beta.Agent` instantiation pattern.
- 🥪 **Uses Daytona sandbox** — eligible for the $3K Daytona prize. Check how they wire `code_execution` to a Daytona container.
- 🌐 **Browser-extension shell** — interesting deployment surface.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/Shaivpidadi/Mycelium` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 8. **pest off**
> _a multi-modal sdk for agriculture robots that specifies issues down to a single plant & handles it without spamming pesticides._

- **Captain / 队长:** Ryan Rana
- **Members / 成员:** ryanrana04@gmail.com (Ryan Rana) [owner]; naibingjiang@gmail.com (Naibing); as7915@columbia.edu (Lika)
- **Repo:** https://github.com/RyanRana/ag2-hack
- **Video:** https://www.youtube.com/watch?v=LR5ngp0NJ7Y
- **Total score / 总分:** — / 25
- **Description:** Pest off is a multi-modal SDK for agricultural robots that pinpoints problems down to a single plant and handles them without spamming pesticides. It fuses computer vision, physics simulation, population biology, and local LLM reasoning into one inference engine that tells robots which plants to laser, spray, irrigate, or leave alone. This matters because modern agriculture blankets fields with chemicals that destroy soil health, kill pollinators, and breed resistance when 90% of plants need nothing at all. We built it on AG2 because typed agent communication and inference-driven…

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/RyanRana/ag2-hack` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 9. **Mesh Shield**
> _Software-defined counter-swarm defense — your cameras are the sensor network_

- **Captain / 队长:** RS
- **Members / 成员:** rsusny@gmail.com (RS) [owner]
- **Repo:** https://github.com/roshaninfordham/meshshieldai
- **Video:** ag2 hACKATHON Product demo video
- **Total score / 总分:** 15 / 25
- **Sub-scores / 分项:** Innovation & creativity: 5 · Technical execution: 2 · Impact & usefulness: 4 · Use of AG2 / multi-agent design: 4
- **Description:** The five agents: 1. Threat Prioritizer (Gemini 2.5 Flash) — reads the snapshot, returns ranked targets with risk scores and intent estimates. 2. Interceptor Allocator (Gemini 2.5 Flash) — for each prioritized target, sweeps each available interceptor through simulate_intercept_path, which runs ballistic projection (in a Daytona sandbox in production, with local numpy fallback). Picks one assignment per target. 3. Justifier (Gemini 2.5 Flash) — calls Tavily for live counter-UAS news, then attaches a justification trace to each assignment citing snapshot field paths, news headlines, and policy…

**🪜 拿来主义指南 / Fork & improve guidance:**

- ✅ **Uses AG2 Beta.** Worth studying its `autogen.beta.Agent` instantiation pattern.
- 🥪 **Uses Daytona sandbox** — eligible for the $3K Daytona prize. Check how they wire `code_execution` to a Daytona container.
- 🔎 **Live web search via Tavily** — copy the search-curator agent pattern.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/roshaninfordham/meshshieldai` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 10. **Verity**
> _Evidence ledger for AI-generated code._

- **Captain / 队长:** Advik Bhatt
- **Members / 成员:** advikbwork@gmail.com (Advik Bhatt) [owner]
- **Repo:** https://github.com/advik-bhatt/verity
- **Live demo:** https://verity-smoky-one.vercel.app
- **Video:** https://www.youtube.com/watch?v=dQw4w9WgXcQ
- **Total score / 总分:** 10 / 25
- **Sub-scores / 分项:** Innovation & creativity: 3 · Technical execution: 2 · Impact & usefulness: 3 · Use of AG2 / multi-agent design: 1 · Presentation & demo: 1
- **Description:** Verity Protocol is a connector-first evidence ledger for AI-generated code. AI coding tools make code arrive faster than trust. Verity turns risky AI-assisted pull requests into structured case files that show where the code came from, which fixes were considered, what evidence ran, which policies fired, and what needs to happen before merge. The core workflow is: GitHub PR → Origin Map → Risk Classification → Patch Space → Sandbox Evidence → Policy → Verdict The main idea is Patch Space. A single AI-generated patch can look correct while hiding assumptions about blast radius, missing tests,…

**🪜 拿来主义指南 / Fork & improve guidance:**

- 🥪 **Uses Daytona sandbox** — eligible for the $3K Daytona prize. Check how they wire `code_execution` to a Daytona container.
- 🛠 **FastAPI backend** — good template for serving multi-agent output.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/advik-bhatt/verity` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

## 🔬 Track: scientific / 科研加速  (10 repos)

### 11. **Research_paper_synthesizer**

- **Captain / 队长:** kevin
- **Members / 成员:** kevinhui98@gmail.com (kevin) [owner]
- **Repo:** https://github.com/azhao18/AG2_Hackathon/tree/kevin
- **Video:** https://youtu.be/JdWk9s52EAk
- **Total score / 总分:** 6 / 25
- **Sub-scores / 分项:** Innovation & creativity: 1 · Technical execution: 1 · Impact & usefulness: 1 · Use of AG2 / multi-agent design: 2 · Presentation & demo: 1
- **Judge notes / 评委备注:** Barely done, just agent that extracts data from pdf
- **Description:** Layer 1 extracts key elements like research question, methodology, findings, effect size, limitations, and assumptions to standardize each paper. future: Layer 2 synthesizes across papers to identify consensus, disagreements, clusters of approaches, and trends over time. Layer 3 builds structured reasoning by generating pro and con arguments and assigning a confidence score based on evidence quality. The overall goal is to move from raw text to evidence-backed conclusions, though it depends heavily on consistent extraction and clear evaluation criteria.

**🪜 拿来主义指南 / Fork & improve guidance:**

- ⚠️ **Low judge score** — shows what to avoid (often: bolted-on AG2 use or thin UX).

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/azhao18/AG2_Hackathon/tree/kevin` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 12. **RefereeOS**
> _RefereeOS breaks the bottleneck of human reviewer systems for scientific pre-prints._

- **Captain / 队长:** Vincent DiPaola
- **Members / 成员:** vincentjdipaola@gmail.com (Vincent DiPaola) [owner]
- **Repo:** https://github.com/VJDiPaola/RefereeOS
- **Video:** https://youtu.be/1QFJeUW-KRg 
- **Total score / 总分:** — / 25
- **Sub-scores / 分项:** Innovation & creativity: (4)

- Good use of AI to help review and validation of papers.
- Great frontend (though would have liked it to be more fluid)
 · Technical execution: 4 · Impact & usefulness: 4 · Use of AG2 / multi-agent design: 3

- Uses AG2 ConversableAgent (no beta)
- Uses Daytona (but does not use AG2 inside Daytona, uses direct OpenAI request)
- Different agents but no orchestration (sequential flow only) · Presentation & demo: 3
- **Description:** What We Built RefereeOS is a reviewer-prep system for scientific papers. It turns a manuscript into an auditable evidence board with extracted claims, supporting evidence, methodological/statistical concerns, integrity flags, reproducibility results, related-work risks, and a final reviewer packet for human editors. It includes a React dashboard, FastAPI backend, fixture and upload flows, prompt-injection detection, claim-linked concern mapping, a Daytona reproducibility sandbox path, OpenAI GPT-5.5 receipt interpretation, and optional AG2 + Gemini area-chair synthesis when configured. How It…

**🪜 拿来主义指南 / Fork & improve guidance:**

- 🥪 **Uses Daytona sandbox** — eligible for the $3K Daytona prize. Check how they wire `code_execution` to a Daytona container.
- 🛠 **FastAPI backend** — good template for serving multi-agent output.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/VJDiPaola/RefereeOS` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 13. **ECAG2**
> _From raw ECG samples to AI consensus: digital signal processing meets multi-agent clinical reasoning._

- **Captain / 队长:** Zackk
- **Members / 成员:** zj28@njit.edu (Zackk) [owner]
- **Repo:** https://github.com/zack1111111111111/ECAG2
- **Live demo:** https://youtu.be/h53X8jO6bhg
- **Video:** https://youtu.be/h53X8jO6bhg
- **Total score / 总分:** — / 25
- **Description:** ## What it is A real-time ECG monitor that pairs classical DSP with a multi-agent AI cardiology team. Raw waveforms from PhysioNet flow through Pan-Tompkins QRS detection; extracted features are then debated by two LLM agents that commit to a diagnosis. ## How it works **Signal layer.** Pan-Tompkins (1985) — bandpass 5–15 Hz, derivative, squaring, 150 ms integration, adaptive thresholding — extracts R-peaks from raw ECG. We compute heart rate, HRV (SDNN), RR coefficient of variation, ectopic ratio, and R-peak amplitude over a 30-second window. **Reasoning layer.** Built on AG2 with Claude…

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/zack1111111111111/ECAG2` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 14. **lionag2**
> _auto research with shared knowledge_

- **Captain / 队长:** Haiyang Li
- **Members / 成员:** quantocean.li@gmail.com (Haiyang Li) [owner]
- **Repo:** https://github.com/khive-ai/lionag2
- **Video:** https://khive.ai
- **Total score / 总分:** — / 25
- **Description:** Recursive self corrective exploratory scientific research via multi agent collaboration, persistent memory, shared knowledge graph and intra-agent communication.

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/khive-ai/lionag2` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 15. **Pippette twin**
> _Digital twin for biological research_

- **Captain / 队长:** Isayah Culbertson
- **Members / 成员:** isayahculbertson@gmail.com (Isayah Culbertson) [owner]
- **Repo:** https://github.com/isayahc/pipetting-twin
- **Video:** https://youtu.be/XV6GJVFLNCk
- **Total score / 总分:** — / 25
- **Description:** ## Description We build a pipetting digital twin application that searches the web to generate protocols then predicts that outputs. In real world settings this would be compared to real pipetting robots. ## Why we built it We are developing the intelligence layer of the summation of many experiments on existing or theoretical lab infrastructure. This creates a feedback mechanism such to allow for physical and digital representation of experiments to converge.

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/isayahc/pipetting-twin` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 16. **SciSift**
> _40% of papers won't reproduce. Know which ones._

- **Captain / 队长:** Icesummercream
- **Members / 成员:** zhxiyiok@gmail.com (Icesummercream) [owner]
- **Repo:** https://github.com/pandaji/ag2-hackathon
- **Video:** https://www.youtube.com/watch?v=YurpDwKTGGY
- **Total score / 总分:** — / 25
- **Description:** What is it: ReproAgent is a multi-agent AI system that automatically verifies the reproducibility of ML research papers. Researchers drop in a paper PDF or arXiv URL, and the system returns a structured reproducibility card — with a ✅ / ⚠️ / ❌ verdict for each claimed result — in minutes rather than the months a human peer reviewer would need. How it works: Built on AG2's GroupChat framework, the pipeline chains five specialized agents: a Reader agent extracts quantitative claims and metric targets from the paper; a Retriever agent uses Tavily to locate the associated code repository and…

**🪜 拿来主义指南 / Fork & improve guidance:**

- 🥪 **Uses Daytona sandbox** — eligible for the $3K Daytona prize. Check how they wire `code_execution` to a Daytona container.
- 🔎 **Live web search via Tavily** — copy the search-curator agent pattern.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/pandaji/ag2-hackathon` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 17. **Summit-Life-Science ResearchOS**
> _Summit ResearchOS turns one early product idea into a research-backed, regulatory-aware, lab-ready starter dossier._

- **Captain / 队长:** Yang Zhang
- **Members / 成员:** yang@ahfvitamins.com (Yang Zhang) [owner]
- **Repo:** https://github.com/ZacharyZhang-NY/SLS-Researcher
- **Live demo:** https://sls-researcher-g9hcfmvpwaprfu5av8kyqu.streamlit.app/
- **Video:** https://youtu.be/gUPoqXFRLE0
- **Total score / 总分:** 18 / 25
- **Sub-scores / 分项:** Innovation & creativity: 3 · Technical execution: 3 · Impact & usefulness: 4 · Use of AG2 / multi-agent design: 4 · Presentation & demo: 4
- **Description:** Summit ResearchOS turns one early product idea into a research-backed, regulatory-aware, lab-ready starter dossier. A client says: “I want to develop a brain health supplement using Rhodiola for the U.S. market.” AG2 agents then collaborate across research, literature review, regulatory pre-check, and lab planning. Tavily Search brings in current web and FDA sources. Daytona provides a secure sandbox for running the workflow and previewing the app. The output is a Summit-style starter dossier that helps BD, R&D, Regulatory, and Lab teams align faster.

**🪜 拿来主义指南 / Fork & improve guidance:**

- 🥪 **Uses Daytona sandbox** — eligible for the $3K Daytona prize. Check how they wire `code_execution` to a Daytona container.
- 🔎 **Live web search via Tavily** — copy the search-curator agent pattern.
- 🥇 **Top-tier score** — high-fidelity reference; worth full code-walk.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/ZacharyZhang-NY/SLS-Researcher` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 18. **BioForge**
> _Take hypothesis to experiment in couple of mintues._

- **Captain / 队长:** Jian Jin Chen
- **Members / 成员:** jianjinchen59@gmail.com (Jian Jin Chen) [owner]
- **Repo:** https://github.com/JJC3321/BioForge
- **Video:** https://www.loom.com/share/8a9634bcae664aeda69803f41c02f46c
- **Total score / 总分:** 12 / 25
- **Sub-scores / 分项:** Innovation & creativity: 2 · Technical execution: 2 · Impact & usefulness: 2 · Use of AG2 / multi-agent design: 3 · Presentation & demo: 3
- **Description:** BioForge is an innovative AI-powered tool that transforms biology research hypotheses into ready-to-execute wet-lab experiments, streamlining the critical gap between scientific ideas and practical protocols. Users input a hypothesis, such as testing a gene's role in cell signaling, and BioForge's multi-agent system (built with AG2) rapidly generates complete experiment designs, including materials lists, step-by-step procedures, timelines, budgets, and quality checks via literature validation. It is focused on real-world lab usability: human-in-the-loop feedback iteratively refines outputs,…

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/JJC3321/BioForge` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 19. **Multi-Agent Research Paper Assistant**

- **Captain / 队长:** Mike wang
- **Members / 成员:** mikewangfangxing@gmail.com (Mike wang) [owner]; liang.x.guo@gmail.com (Leon); martyjia@gmail.com (Marty Jia)
- **Repo:** https://github.com/guocity/ag2_event_code
- **Video:** https://github.com/guocity/ag2_event_code
- **Total score / 总分:** — / 25
- **Description:** We're building a multi-agent scientific research demo. One agent extracts data, one synthesizes, one critiques, one summarize all information into a report

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/guocity/ag2_event_code` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 20. **Get me Up2Date**
> _A Multi-Agent Tool that can research, cull, summarize, and report on the latest scientific findings_

- **Captain / 队长:** EZ
- **Members / 成员:** bringezback@gmail.com (EZ) [owner]
- **Repo:** https://github.com/0ethel0zhang/ag2_hack/tree/main
- **Video:** https://youtu.be/9-idognc8yQ
- **Total score / 总分:** — / 25
- **Description:** This project leverages the **AG2 Beta** framework to build sophisticated multi-agent systems. The current implementation demonstrates a parallel web research pattern where a lead agent coordinates specialized researchers. ## Architecture & Technology Stack - **Framework:** AG2 Beta (`autogen.beta`) - **LLM Providers:** Primarily Google Gemini (configured via `GeminiConfig`) and OpenAI (configured via `OpenAIConfig`). - **Tools:** - `TavilyClient`: Used for web searching (`tavily_search`) and content extraction (`fetch_url`). - **Core Pattern:** - **Lead Agent:** Decomposes complex questions…

**🪜 拿来主义指南 / Fork & improve guidance:**

- ✅ **Uses AG2 Beta.** Worth studying its `autogen.beta.Agent` instantiation pattern.
- 🔎 **Live web search via Tavily** — copy the search-curator agent pattern.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/0ethel0zhang/ag2_hack/tree/main` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

## 💡 Track: open / 开放赛道  (1 repos)

### 21. **memo-in-browser-ag2**

- **Captain / 队长:** Amy
- **Members / 成员:** mengyuel.liu@gmail.com (Amy) [owner]
- **Repo:** https://github.com/amlworks/ag2-browser-agent.git
- **Video:** https://drive.google.com/drive/folders/1YESoavktPJkkRQGQO5prF4RNiU29vm8h?usp=drive_link
- **Total score / 总分:** 17 / 25
- **Sub-scores / 分项:** Innovation & creativity: 4 · Technical execution: 3 · Impact & usefulness: 5 · Presentation & demo: 5
- **Description:** # Memory Agent A Chrome side-panel companion that turns your **browser history** into a **personal knowledge base** — local, private, free, and exportable to Obsidian. Tell it a learning goal in plain language. It scans your actual browsing, compares it to your saved knowledge, and surfaces patterns. Save pages with one click. Build up a graph. Export to a real Obsidian vault. All powered by free-tier LLM APIs. > *"Looking at the last 60 days, you've been on substack.com a lot for LLM stuff (12 posts) and dev.to for React (8 posts). You've saved 3 of those. Want me to summarize the…

**🪜 拿来主义指南 / Fork & improve guidance:**

- 🔎 **Live web search via Tavily** — copy the search-curator agent pattern.
- 🌐 **Browser-extension shell** — interesting deployment surface.
- 🥇 **Top-tier score** — high-fidelity reference; worth full code-walk.

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/amlworks/ag2-browser-agent.git` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

## 📦 Track: unspecified / 赛道未声明  (5 repos)

### 22. **FutureMe**
> _AG2 for Multi-Agent Collaboration_

- **Captain / 队长:** None
- **Repo:** https://github.com/LilChainyy/future-me.git
- **Video:**  https://youtu.be/w4S_NPuPgEY?si=6KdSg2PJe9lU5JJ0
- **Total score / 总分:** — / 25

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/LilChainyy/future-me.git` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 23. **Money Heist**

- **Captain / 队长:** None
- **Repo:** https://github.com/MichaelFehdrau0205/moneyheist.git
- **Video:** https://www.youtube.com/watch?v=46cXFUzR9XM
- **Total score / 总分:** — / 25

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/MichaelFehdrau0205/moneyheist.git` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 24. **Team Concord'**
> _AG2 for Multi-Agent Collaboration_

- **Captain / 队长:** None
- **Repo:** https://github.com/d3v07/AG2_Hackathon
- **Video:** https://youtu.be/YXVohOp4Pkk
- **Total score / 总分:** — / 25

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/d3v07/AG2_Hackathon` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 25. **SynapSpace AI is an AG2-powered operating system for events.**

- **Captain / 队长:** None
- **Repo:** https://github.com/hasanulchow/SynapSpace-AG2-Playground.git
- **Video:** https://www.youtube.com/watch?v=NhQ56eG2QkM
- **Total score / 总分:** — / 25

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/hasanulchow/SynapSpace-AG2-Playground.git` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

### 26. **Agent Airlock**

- **Captain / 队长:** None
- **Repo:** https://github.com/du-song/ag2-test/
- **Video:** https://www.dropbox.com/scl/fi/6bx1d3orinmo531dr3qd8/demo.mov?rlkey=2vke3vhp0mrukxgwbfrvig3ee&st=ktdauo7t&dl=0
- **Total score / 总分:** — / 25

**🪜 拿来主义指南 / Fork & improve guidance:**

建议改造路径 / Suggested upgrade path:
1. `git clone https://github.com/du-song/ag2-test/` & make it run end-to-end (record any `requirements.txt` gaps in your AI_LOG).
2. Rewrite **one** agent using `autogen.beta.Agent` if the repo still uses legacy `autogen.agentchat`. (+3 Elite20 bonus)
3. Add a **second cooperating agent** (sub-task delegation or agent-as-tool) to deepen the multi-agent design score.
4. Replace any hard-coded API keys with `.env` + `dotenv`; add this to your README "5-min setup".
5. Record a fresh 60–90 s Loom; ensure 'Anyone with the link' is enabled.
6. In your `ATTRIBUTION.md`, cite this repo as the fork source and list the agent files / prompt blocks you reused.

---

## 📌 Picking your base repo / 选择你的起点

Decision table — choose by what you want to learn:

| 你想练的能力 / Skill you want | 推荐起点 / Recommended base | 原因 / Why |
|------------------------------|-----------------------------|-----------|
| Async multi-agent orchestration | **Mycelium** | 5 hand-written `autogen.beta.Agent` C-suite leads — clean Beta example. |
| Scientific research workflow | **Summit-Life-Science ResearchOS** | High-scoring (18/25), includes regulatory-aware reasoning. |
| Browser-deployed agent | **memo-in-browser-ag2** | High-scoring (17/25) Open-track entry; Chrome side-panel, exports to Obsidian. |
| Trading / market-data pipeline | **Trading With Alpaca** | Full stack: market data + order mgmt + Redis + web GUI. |
| Form automation + tools | **FillNinja** | Browser ext + FastAPI + AG2 multi-agent. |
| Reproducibility / paper QA | **SciSift / RefereeOS** | Both tackle scientific paper QA from different angles. |
| Bio / wet-lab | **Pippette twin** or **BioForge** | Two complementary takes on the lab digital-twin idea. |
| Counter-swarm / surveillance | **Mesh Shield** | 5-agent threat → interceptor allocator pipeline. |
| Code-quality / PR review | **Verity** or **Codescan** | Both target the AI-generated-code provenance space. |

---

## 🚫 反面教材 / Anti-patterns to avoid

Judges' notes (from the spreadsheet) flagged several anti-patterns; learn from these before you start:

- **Bolted-on AG2.** RefereeOS used `ConversableAgent` + a direct OpenAI request inside Daytona instead of routing through AG2 — "sequential flow only, no orchestration". Make your AG2 use **structural**, not decorative.
- **"Just an agent that extracts data from a PDF."** Research_paper_synthesizer scored 6/25 because it stopped at single-agent extraction — no synthesis layer, no critic, no report.
- **Missing demo video.** Multiple submissions scored 0 on Presentation simply because the judges couldn't open the Loom ("Anyone with the link" was off).
- **Track misalignment.** Several Multi-Agent track repos used a single agent — auto-fail on the Multi-Agent design criterion.

---

## 🧷 Citing this catalog in your ATTRIBUTION.md

Required boilerplate (verbatim — Elite20 拿来主义 principle):

```markdown
## Source / 拿来源
- Catalog: Elite20 C5-AG2 sample repos (`samples/submitted_repos.md`).
- Base repo: <project name> — <repo URL>
- Captain of base repo: <name>
- Snippets reused (file path + commit SHA): <list>
- What I changed / added: <list>
```
