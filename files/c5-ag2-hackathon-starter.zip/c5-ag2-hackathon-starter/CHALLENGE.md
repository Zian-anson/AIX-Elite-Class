# Challenge 5-AG2: AG2 Hackathon Repo (Bilingual / 中英对照)

> 🎯 **C5 的 AG2 多智能体变体。** 在 AG2 (formerly AutoGen) 框架上从零开始（或站在 25 个 hackathon 已有项目肩膀上），构建一个**可复现、可演示**的 multi-agent GitHub repo。
>
> 🎯 **An AG2-flavored variant of C5.** Build a reproducible, demo-able multi-agent GitHub repo on the AG2 framework — from scratch or, preferably, by forking and improving one of the 25 existing AG2 hackathon submissions.

---

## 0 | 一句话定位 / One-line positioning

| | 中文 | English |
|---|------|---------|
| **输入 / Input** | 任意一个 hackathon 已交付 repo（见 `samples/submitted_repos.md`），或一个新的 multi-agent 想法 | Any submitted hackathon repo (see `samples/submitted_repos.md`) or a new multi-agent idea |
| **产出 / Output** | 你自己的 GitHub repo + 60–90 秒 demo 视频 + 完整 README + AI_LOG + ATTRIBUTION | Your own GitHub repo + 60–90s demo video + full README + AI_LOG + ATTRIBUTION |
| **门槛 / Bar** | 别人 `git clone` → 5 分钟内能跑 → 主流程 ≥ 2 个协作 agent | Anyone can `git clone` → run within 5 min → main loop has ≥ 2 cooperating agents |

---

## 一、为什么要单独做一个 AG2 变体？/ Why a dedicated AG2 variant?

普通 C5 接受任意 GitHub repo。**C5-AG2 把"多智能体协作"作为硬约束**，理由是：

C5 accepts any GitHub repo. **C5-AG2 makes "multi-agent collaboration" a hard constraint**, because:

| 中文理由 | English reason |
|---------|----------------|
| Elite20 的核心命题是"人 + Agent 共生" — 你必须先会编排 agent | Elite20's thesis is "human + agent symbiosis" — you must first learn to orchestrate agents |
| AG2 是当前 multi-agent 领域最成熟的开源框架（前身 AutoGen，由微软研究院孵化） | AG2 is the most mature open-source multi-agent framework (formerly AutoGen, incubated at Microsoft Research) |
| 已经有 25 个真实 hackathon repo 可"拿来"——拿来主义最完美的训练场 | 25 real hackathon repos already exist for 拿来主义 (fork-and-improve) practice |
| 多模型/多 agent 系统是 C8 / C9 / C10 的基础——这里学不会，后面跟不上 | Multi-agent systems are the foundation of C8 / C9 / C10 — fall behind here, fall behind everywhere |

---

## 二、AG2 框架核心知识 / AG2 Framework Core Knowledge

> **完整离线缓存：** `references/ag2_docs/` 含 24 个文档（README、Quickstart、Beta 文档、代码示例、工具、测试、遥测）。
>
> **Full offline cache:** `references/ag2_docs/` contains 24 docs (README, Quickstart, Beta docs, code examples, tools, testing, telemetry).

### 2.1 AG2 vs AG2 Beta（重要！/ Important!）

| | AG2 (legacy) | AG2 Beta (推荐 / recommended) |
|---|--------------|------------------------------|
| Module | `autogen` / `autogen.agentchat` | `autogen.beta` |
| 核心类 / Core class | `ConversableAgent`, `GroupChatManager` | `Agent`, `Reply`, `ModelConfig` |
| API 风格 / API style | sync, message-based | **async-first**, `agent.ask(...)` / `reply.ask(...)` |
| 状态 / State | in-memory | **externalised** via `History` / `Storage` / `Stream` protocols (Redis, DB, etc.) |
| 何时用 / When | 现有项目 / existing projects, 兼容老代码 | **本次 hackathon 默认 / default for this hackathon** |

**结论 / Bottom line:** 默认用 `autogen.beta`。本 challenge 的所有评分加成都假设你用 Beta。

### 2.2 最小可运行示例 / Minimal runnable example

```python
# 来自 references/ag2_docs/20_beta_example_hello_agent.mdx
import asyncio
from autogen.beta import Agent
from autogen.beta.config import GeminiConfig

async def main():
    agent = Agent(
        "greeter",
        prompt="You are concise. Reply in one sentence.",
        config=GeminiConfig(model="gemini-3-flash-preview", temperature=0),
    )
    reply = await agent.ask("Give me one tip for learning chess.")
    print(reply.body)

asyncio.run(main())
```

### 2.3 多 agent 协作模式 / Multi-agent collaboration patterns

| 模式 / Pattern | 何时用 / When | 文档 / Doc |
|---------------|--------------|-----------|
| **Agent-as-tool** | 一个 lead agent 把其他 agent 作为 tool 调用 | `references/ag2_docs/11_beta_agents.mdx` |
| **Sub-task delegation** | 长任务分发给专家 agent，独立 stream，并行 `asyncio.gather` | `references/ag2_docs/13_beta_task_delegation.mdx` |
| **GroupChat** (legacy AG2) | 多 agent 共享一个 conversation thread | `references/ag2_docs/docs_groupchat.mdx` |
| **Swarm** (legacy AG2) | 状态机式 handoff (Cherrydev 之前的版本是这种) | (mentioned in motivation doc) |
| **A2A networking** | 跨进程/跨服务的 agent 协议 | `references/ag2_docs/10_beta_motivation.mdx` |

### 2.4 必读文档清单 / Must-read doc list

按这个顺序读，**45 分钟内**能从零到能写代码：

Read in this order — from zero to coding in **under 45 minutes**:

1. `00_ag2_main_readme.md` — 项目全景
2. `10_beta_motivation.mdx` — 为什么 Beta，新旧差异
3. `20_beta_example_hello_agent.mdx` — 最小可运行示例
4. `11_beta_agents.mdx` — Agent 类的 API
5. `30_beta_tools_builtin.mdx` — 内置工具 (web search, code exec, memory)
6. `21_beta_example_research_squad.mdx` — 多 agent 协作完整例子
7. `31_beta_tools_code_execution.mdx` — 让 agent 跑代码（Daytona 推荐）

---

## 三、Hackathon 复刻规则 / Reconstructed Hackathon Rules

> 来源：https://ag2-hackathon.vercel.app（提取于 2026-05-04）
> 完整还原版见 `references/hackathon/hackathon_brief.md`。

### 3.1 三条赛道 / Three tracks

| Track Key | 中文名 | English name | 一句话 / Description |
|-----------|--------|--------------|----------------------|
| `scientific` | AG2 科研加速 | AG2 for Scientific Research | 加速文献综述、数据分析、实验设计、可复现性的 multi-agent 系统 / Multi-agent systems that accelerate research workflows — literature review, data analysis, experiment design, reproducibility |
| `multi-agent` | AG2 多智能体协作 | AG2 for Multi-Agent Collaboration | 设计协调互补的 agent — GroupChat / Swarm / A2A — 解决单 agent 解决不了的问题 / Design agents that coordinate — GroupChat, Swarm, A2A networking — to solve problems a single agent can't |
| `open` | 开放赛道 | Open | 任何能在一天内用 AG2 交付的项目，给我们惊喜 / Anything else you can ship with AG2 in a day. Surprise us. |

### 3.2 评分维度 (0–5 / 各, 总分 25) / Judging rubric (0–5 each, total 25)

| # | Criterion | Max | What to look for |
|---|-----------|-----|------------------|
| 1 | **Innovation & creativity** | 5 | Original idea, novel application, creative framing. |
| 2 | **Technical execution** | 5 | Does it work? Code quality, complexity, completeness. |
| 3 | **Impact & usefulness** | 5 | Solves a real problem; scientific or business value. |
| 4 | **Use of AG2 / multi-agent design** | 5 | Meaningful use of the framework — not bolted on. |
| 5 | **Presentation & demo** | 5 | Clarity of video, repo README, tagline. |
| | **TOTAL** | 25 | Highest total wins. Tie-break: Innovation. |

完整 rubric YAML 见 `references/hackathon/rubric.yaml`。
Full rubric YAML in `references/hackathon/rubric.yaml`.

### 3.3 奖项 / Prize categories

| 奖项 / Prize | 内容 / Detail |
|------|----|
| Best Scientific Research agent | Most impactful AG2-powered research workflow. |
| Best Multi-Agent Collaboration | Best GroupChat / Swarm / A2A coordination. |
| Best Overall | The team that most impressed judges across the board. |
| Daytona Sandbox Prize | $3,000 in Daytona credits for the winning project that uses a Daytona sandbox. |
| Open Source bonus | Open a PR to `ag2ai/ag2` during the hackathon → bonus points toward any of the top 3 prizes. |

### 3.4 提交清单 / Submission checklist (复刻 hackathon 表单 / mirroring the hackathon form)

- Project name & 60-character tagline
- Track (`scientific` / `multi-agent` / `open`)
- Captain name + email
- Team emails (raw)
- Repo URL
- Demo URL (live deployment if any)
- Video URL (60–90 秒, Loom must be "Anyone with the link can view")
- Thumbnail URL
- Description (multi-paragraph markdown)

---

## 四、Elite20 提交规范 / Elite20 Submission Rules

C5-AG2 在 hackathon 标准之上，**额外要求** Elite20 两大原则的证据：

C5-AG2 adds Elite20's two principles on top of the hackathon baseline:

| 文件 / File | 命名 / Naming | 内容 / Content |
|------------|--------------|----------------|
| Repo URL | `姓名_C5-AG2_repo.md` | GitHub URL + 一句话项目说明 |
| README screenshot | `姓名_C5-AG2_readme.png` | 可选 / Optional |
| **AI_LOG.md** | repo 内 `/AI_LOG.md` | 用了什么 AI、几轮迭代、手动步骤反向举证 / What AI you used, iterations, manual-step justification |
| **ATTRIBUTION.md** | repo 内 `/ATTRIBUTION.md` | 你 fork 了哪个 sample repo？哪些代码段抄了 AG2 文档？哪个 agent 模式借自哪个 hackathon 项目？ |
| Submission text | 群消息 / Group message | "我的 C5-AG2: <URL> — <track> — 输入____输出____" |

模板见 `templates/AI_LOG_template.md` 和 `templates/ATTRIBUTION_template.md`。
Templates in `templates/AI_LOG_template.md` and `templates/ATTRIBUTION_template.md`.

---

## 五、拿来主义快路径 / 拿来主义 Fast-Path

完整路径见 `samples/submitted_repos.md`（25 个 repo + 拿来指南）。这里是最短路径：

Full path in `samples/submitted_repos.md` (25 repos + how to fork). Shortest path:

```
Step 1 (10 min) — 浏览 samples/submitted_repos.md，按你的赛道挑 1 个 base repo
                  Browse samples table, pick 1 base repo matching your track.
Step 2 (5 min)  — Fork 它到你的 GitHub
                  Fork it to your GitHub.
Step 3 (30 min) — git clone, 让它能跑（按 README）
                  Clone, get it running per README.
Step 4 (2-4 hr) — 用 AG2 Beta 重写一个 agent，或加一个新 agent
                  Rewrite one agent in AG2 Beta, or add a new agent.
Step 5 (30 min) — 写新的 README + AI_LOG + ATTRIBUTION（注明 fork 源）
                  Write new README + AI_LOG + ATTRIBUTION (cite fork source).
Step 6 (15 min) — 录 60-90 秒 demo 视频
                  Record 60-90s demo video.
Step 7 (5 min)  — 群里发链接 + tagline
                  Share repo link + tagline.
```

**总时间：~5 小时**，从零（不会编程也行——AI 全程辅助）到一个 hackathon 级别 multi-agent repo。

**Total time: ~5 hours**, from zero (you don't need to be a coder — AI assists throughout) to a hackathon-grade multi-agent repo.

---

## 六、评判与录取 / Judging & Admission

C5-AG2 与 hackathon 一样按 25 分评分，但 Elite20 额外加成：

C5-AG2 uses the 25-point hackathon rubric, plus Elite20 bonuses:

| 加成 / Bonus | +分 | 触发 / Trigger |
|--------------|-----|---------------|
| 完整 AI_LOG | +2 | 至少 5 轮可验证 AI 迭代 / ≥5 verifiable AI iterations |
| 完整 ATTRIBUTION | +2 | 显式声明 fork 源 + 借鉴片段 / explicit fork source + cited snippets |
| 用 AG2 Beta 而非 legacy | +3 | `autogen.beta` import 出现在主流程 / `autogen.beta` import in main loop |
| Open-source PR to ag2ai/ag2 | +3 | hackathon 原本就有这个加成 / mirrors hackathon bonus |
| 别人成功复用了你的 repo | +5 | 群里有 ≥1 人 fork 你的 repo 提交了 C5-AG2 / ≥1 group member forks your repo for their own C5-AG2 |

> **录取门槛 / Admission threshold:**
> - 25 分基础 + 加成 ≥ 28 → 直接录取 Elite20 / direct admission
> - 25 分基础 ≥ 18 → 进入候选 / shortlist
> - 25 分基础 < 12 → 重做 v2 / redo as v2

---

## 七、与其他挑战的联动 / Cross-challenge linkage

| 挑战 / Challenge | 怎么联动 / How it links |
|-----------------|-----------------------|
| **C4 技能** | 把你的 AG2 agent 打包成可安装的 `.skill` |
| **C5 GitHub** | C5-AG2 直接满足 C5 的全部要求 — **一份提交两份分** / one submission counts for both |
| **C6 Web App** | 把 repo 用 v0/Vercel/Streamlit 部署成可访问产品 |
| **C8 Project A/B/C** | 多 agent workflow 是 NEOLAF 课程生产 + 企业本体 Agent 的核心能力 |
| **C10 Agent 系统** | 你的 multi-agent loop = C10 的 Agent Loop 雏形 |

---

## 八、检查清单 / Final checklist

提交前自查 / Pre-submit self-check:

```
□ Repo public on GitHub
□ README contains: tagline, track, install (5 min), example, AG2 Beta version used
□ Main loop imports autogen.beta and uses ≥ 2 agents
□ AI_LOG.md present with ≥ 5 iterations
□ ATTRIBUTION.md present with explicit fork source / cited snippets
□ 60–90s video accessible (Loom: 'Anyone with the link' enabled)
□ requirements.txt or pyproject.toml lists ag2 / pyautogen
□ License (MIT or Apache 2.0)
□ .gitignore (no API keys)
□ Group message: link + tagline + track
```

---

> 📣 **C5-AG2 的本质 / Essence:**
>
> 不是从零写一个 agent — 而是**站在 25 个 hackathon 项目肩膀上，用 AG2 Beta 把一个想法做成"5 分钟能跑、60 秒能讲"的 multi-agent 产品**。
>
> Not building from scratch — **standing on the shoulders of 25 hackathon projects, using AG2 Beta to ship a multi-agent product that runs in 5 minutes and pitches in 60 seconds**.
>
> 拿来 → 改造 → 加个 agent → 录视频 → 发布。
> Borrow → refactor → add an agent → record → ship.
