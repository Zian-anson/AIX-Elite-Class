# AG2 Hackathon — Reconstructed Brief / 复刻版

> **Source / 来源:** https://ag2-hackathon.vercel.app
> **Reconstruction date / 复刻日期:** 2026-05-04
> **Method / 方法:** UI strings extracted from the React SPA bundle (`assets/index-DjdWSrY9.js`) + the judging spreadsheet from the actual event (4 May 2026 NYC).
>
> 这是从 hackathon 网站 JS 包和评委表格中提取并重组的版本，**忠实于原版**但便于离线学习。

---

## 1. Event identity / 活动定位

| | |
|---|---|
| **Name** | AG2 Hackathon |
| **Format** | One-day in-person hackathon |
| **Time window** | 11:00 AM – 4:00 PM ET (build window). Day 0 mixer at 9:30 AM. |
| **Submissions close** | 4:00 PM ET |
| **Registration** | Luma (https://luma.com/42lzgbrz). Sign-in to the dashboard requires a Luma-approved email. |
| **Hosts** | Qingyun Wu (AG2 co-founder & CEO) and Vasiliy Radostev (AG2 Head of Engineering). |
| **Featured judge / mentor** | Dinesh Verma, IBM Fellow — https://research.ibm.com/people/dinesh-verma |

---

## 2. Three tracks / 三条赛道

### Track A: AG2 for Scientific Research / AG2 科研加速

> "Build multi-agent systems that accelerate research workflows — literature review, data analysis, experiment design, or reproducibility."
>
> 构建加速科研工作流的 multi-agent 系统——文献综述、数据分析、实验设计、可复现性。

**Examples from the May-2026 cohort** (see `samples/submitted_repos.md`):
- *Research_paper_synthesizer* — extracts standardized fields from PDFs.
- *RefereeOS* — auditable evidence board for scientific pre-prints.
- *Pipette twin* — digital twin for biology lab pipetting.
- *SciSift / ReproAgent* — verifies reproducibility of ML papers.
- *BioForge* — turns hypothesis into wet-lab experiment in minutes.
- *Summit-Life-Science ResearchOS* — regulatory-aware product dossiers.
- *Get me Up2Date* — parallel web research for latest scientific findings.
- *ECAG2* — DSP + multi-agent ECG cardiology team.

### Track B: AG2 for Multi-Agent Collaboration / AG2 多智能体协作

> "Design agents that coordinate with each other — GroupChat, Swarm, A2A networking — to solve problems a single agent can't."
>
> 设计相互协调的 agent——GroupChat、Swarm、A2A 网络——解决单 agent 解决不了的问题。

**Examples**:
- *Mycelium* — five hand-written `autogen.beta.Agent` C-suite leads (CEO/CTO/UI/QA/Tech) decompose, route, review, and ship.
- *Trading With Alpaca* — full trading system with market data, order management, persister, Redis cache, web GUI.
- *FillNinja* — browser extension + AG2 multi-agent backend that fills forms.
- *Codescan* — multi-agent legacy codebase documentation generator.
- *CreatorCrew* — content creator audience finder + content planner.
- *Mesh Shield* — software-defined counter-swarm defense (Threat Prioritizer + Interceptor Allocator + …).
- *Verity* — evidence ledger for AI-generated code (PR risk auditing).
- *kalshi-deep-research* — research-only prediction-market analysis swarm.
- *Life Sandbox* — career-path simulator for new graduates.
- *pest off* — multi-modal SDK for agriculture robots.
- *Agent Airlock*, *Money Heist*, *Team Concord*, *SynapSpace* — see samples table.

### Track C: Open / 开放赛道

> "Anything else you can ship with AG2 in a day. Surprise us."
>
> 任何能在一天内用 AG2 交付的项目。给我们惊喜。

**Examples**:
- *memo-in-browser-ag2 / Memory Agent* — Chrome side-panel that turns browser history into a private knowledge base; exports to Obsidian.

---

## 3. Schedule / 日程

| Phase | What happens |
|-------|--------------|
| **9:30 AM** (Day 0) | Check-in & team formation — Arrive, mingle, find teammates in person. Solo builders welcome. |
| **11:00 AM ET** | Build · Orchestrate · Ship — Heads-down build time begins. |
| **4:00 PM ET** | Submissions close. |
| **After 4:00 PM** | Present · Judge · Award — Team presentations, judging, and awards. |

> "All times local to the venue. We'll announce deadlines again at kickoff."

---

## 4. Prize categories / 奖项

| Prize | Detail |
|-------|--------|
| 🏅 **Best Scientific Research agent** | Most impactful AG2-powered research workflow. |
| 🏅 **Best Multi-Agent Collaboration** | Best GroupChat / Swarm / A2A coordination. |
| 🏆 **Best Overall** | The team that most impressed judges across the board. |
| 🥪 **Daytona Sandbox Prize** | $3,000 in Daytona credits for the winning project that uses a Daytona sandbox. |
| 💚 **Open-Source PR Bonus** | Open a PR to `ag2ai/ag2` during the hackathon — counts as bonus points toward any of the top 3 prizes. |

---

## 5. Judging rubric / 评分标准

Each criterion scored 0–5. Highest total wins; ties broken by Innovation.

| # | Criterion | Max | What to look for |
|---|-----------|-----|------------------|
| 1 | Innovation & creativity | 5 | Original idea, novel application, creative framing. |
| 2 | Technical execution | 5 | Does it work? Code quality, complexity, completeness. |
| 3 | Impact & usefulness | 5 | Solves a real problem; scientific or business value. |
| 4 | Use of AG2 / multi-agent design | 5 | Meaningful use of the framework — not bolted on. |
| 5 | Presentation & demo | 5 | Clarity of video, repo README, tagline. |
| | **TOTAL** | **25** | Highest total wins. Tie-break: Innovation. |

Machine-readable form: `references/hackathon/rubric.yaml`.

---

## 6. Submission form fields / 提交表单字段

These mirror the in-app submission form and the judging spreadsheet columns:

| Field | Required | Notes |
|-------|----------|-------|
| `project_name` | yes | |
| `tagline` | yes | One short line — ≤ 60 characters works best. |
| `track` | yes | one of `scientific` / `multi-agent` / `open` |
| `team_emails` | yes | Solo is fine. Each registered teammate gets edit access; unmatched emails wait until they sign in. |
| `repo_url` | yes | Public GitHub URL. |
| `demo_url` | optional | Live deployment if any. |
| `video_url` | yes | 60–90 seconds. **For Loom: 'Anyone with the link can view' must be on, otherwise judges can't open it.** |
| `thumbnail_url` | optional | |
| `description_md` | yes | Multi-paragraph markdown. |
| `submitted_at` | auto | "You can keep editing after submitting until the deadline." |

---

## 7. Provided tooling / 提供的工具栈

> "Sign in to unlock Gemini, Tavily, and Daytona tokens."

| Tool | What you get | Notes |
|------|-------------|-------|
| **Gemini via OpenRouter** | One key, all Gemini models — managed by AG2 for the event. No GCP account needed. | Models: `google/gemini-2.5-flash`, `gemini-2.5-pro`, `gemini-3.1-flash-lite-preview`, `gemini-3.1-pro-preview`, `gemini-3-flash-preview`. Endpoint: `https://openrouter.ai/api/v1`. |
| **Daytona sandbox** | $100 in sandbox credits, first 120 participants. Coupon: `DAYTONA_AG2_F6D0PS8U`. | Run code in cloud sandboxes from your agents. Wallet: https://app.daytona.io/dashboard/billing/wallet ; LLMs-friendly docs: https://www.daytona.io/docs/llms-full.txt ; Slack: https://daytonacommunity.slack.com . |
| **Tavily** | Live web search from agents. Sign up with your own email. | https://app.tavily.com/home |
| **v0 by Vercel** | $30 in app-generator credits per person, first cohort only. | UI scaffolding from a prompt. |

### 15 AG2 Beta skills auto-loaded into your AI assistant

> "Install AG2 Beta skills into your repo, then open it in Cursor, Claude Code, Codex, Gemini CLI, or OpenCode. 15 AG2 Beta skills load automatically — your AI pair programmer writes correct AG2 code on the first try instead of guessing."

This is the recommended setup for the hackathon — your AI pair-programmer reads canonical Beta examples before generating code.

### Reference repos / 参考实现

- **`build-with-ag2/beta/data-analyst`** — AG2 agent that runs code in a Daytona sandbox.
  https://github.com/ag2ai/build-with-ag2/tree/main/beta/data-analyst
- **`build-with-ag2/beta/mystery-dinner`** — Fuller multi-agent example (browser-rendered murder-mystery game).
  https://github.com/ag2ai/build-with-ag2/tree/main/beta/mystery-dinner

### AG2 Beta documentation entry point

- https://docs.ag2.ai/latest/docs/beta/motivation/ — start here, then the Quickstart and `code_examples/01_hello_agent`.

---

## 8. Operational tips from the brief / 运营贴士

- "Find a team at check-in" — there is a 9:30 AM in-person mixer on Day 0. Solo builders welcome too.
- "Fill in the in-app submission form before the deadline, then present live."
- "Solo is fine. Each registered teammate you list gets edit access."
- For Loom video: **'Anyone with the link can view' must be on**, otherwise judges can't open it.
- "Start with the motivation page — why Beta exists, what's different, and how the Actor model works. This is the surface we want you building on today."

---

## 9. Reconstruction provenance / 复刻溯源

Strings extracted from the SPA bundle that informed this document (representative sample):

```
"AG2 for Scientific Research"
"Build multi-agent systems that accelerate research workflows — literature review, data analysis, experiment design, or reproducibility."
"AG2 for Multi-Agent Collaboration"
"Design agents that coordinate with each other — GroupChat, Swarm, A2A networking — to solve problems a single agent can't."
"Anything else you can ship with AG2 in a day. Surprise us."
"Best Scientific Research agent"
"Most impactful AG2-powered research workflow."
"Best Multi-Agent Collaboration"
"Best Overall"
"The team that most impressed judges across the board."
"Daytona Sandbox Prize"
"$3,000 in Daytona credits for the winning project that uses a Daytona sandbox."
"Open a PR to ag2ai/ag2 during the hackathon — counts as bonus points toward any of the top 3 prizes."
"Innovation & creativity" / "Technical execution" / "Impact & usefulness" / "Use of AG2 / multi-agent design" / "Presentation & demo"
"Highest total wins. Tie-break: Innovation."
"60–90 seconds. For Loom: make sure 'Anyone with the link can view' is on, otherwise judges can't open it."
"Each criterion scored 0–5. Highest total wins; ties broken by Innovation."
"Qingyun Wu (AG2 co-founder & CEO) and Vasiliy Radostev (AG2 Head of Eng)."
"Dinesh Verma, IBM Fellow — https://research.ibm.com/people/dinesh-verma"
```

This document is a faithful reconstruction, not a verbatim copy. For the live UI go to https://ag2-hackathon.vercel.app.
