This file was an early dump that ended up duplicating another file in
this directory. See:
- 04_beta_mystery_dinner.md  (the previous content of raw_README.md)
- 01_quickstart.mdx          (the previous content of raw_quickstart.mdx)
