"""hello_multiagent.py — minimal AG2 Beta multi-agent example.

Proves your environment works AND that you can satisfy the C5-AG2 bar
(≥ 2 cooperating agents on the main loop).

Two agents:
  - LEAD:    decomposes a question, asks the CRITIC, integrates the answer.
  - CRITIC:  scrutinises the lead's draft and replies with a short critique.

Adapted from:
  - references/ag2_docs/20_beta_example_hello_agent.mdx
  - references/ag2_docs/13_beta_task_delegation.mdx

Run:
    python -m venv .venv && source .venv/bin/activate
    pip install -r ../templates/requirements_example.txt
    cp ../templates/env_example.txt .env   # then fill OPENROUTER_API_KEY
    python examples/hello_multiagent.py
"""
from __future__ import annotations

import asyncio
import os

from dotenv import load_dotenv
from autogen.beta import Agent
from autogen.beta.config import GeminiConfig  # any ModelConfig works

load_dotenv()

MODEL = os.getenv("AG2_DEFAULT_MODEL", "google/gemini-3-flash-preview")
# OpenRouter exposes Gemini through the same Gemini SDK surface; AG2's
# GeminiConfig accepts the model slug directly. If you prefer raw OpenAI
# config, swap to OpenAIConfig with base_url=OPENROUTER_BASE_URL.
config = GeminiConfig(model=MODEL.replace("google/", ""), temperature=0.2)


async def main() -> None:
    lead = Agent(
        "lead",
        prompt=(
            "You are LEAD. Given a user question, draft a one-paragraph answer, "
            "ask CRITIC for a short adversarial review using the `consult_critic` "
            "tool you'll have, then revise once and present the final answer."
        ),
        config=config,
    )
    critic = Agent(
        "critic",
        prompt=(
            "You are CRITIC. Given a draft, identify ONE substantive flaw "
            "(empirical, logical, or stylistic) in ≤ 2 sentences. No flattery."
        ),
        config=config,
    )

    # Expose CRITIC to LEAD as a tool — this is the canonical AG2 Beta
    # 'agent-as-tool' pattern. Cited from references/ag2_docs/11_beta_agents.mdx.
    consult_critic = critic.as_tool(
        name="consult_critic",
        description="Send a draft answer to CRITIC and receive a one-flaw review.",
    )
    lead.tools.add(consult_critic)

    question = (
        "In 4 sentences, why are multi-agent systems harder to evaluate than "
        "single-agent systems?"
    )
    print("\n── LEAD turn 1 ───")
    reply = await lead.ask(question)
    print(reply.body)


if __name__ == "__main__":
    asyncio.run(main())
