---
name: hermes-gateway-pid-lock
description: Hermes Gateway PID 锁冲突处理 - 清理残留锁文件解决启动失败
---
# Hermes Gateway PID 锁冲突处理

## 触发条件

运行 `hermes gateway run` 时报错：
```
OSError: [WinError 11] 试图加载格式不正确的程序。
```
或
```
os.kill(pid, 0)  # signal 0 = existence check
```

## 原因

Gateway 进程异常退出，但 PID 锁文件未清理，导致新启动时检查到旧 PID 存在但该进程已无效。

## 清理步骤

检查并删除以下所有文件（路径在 `C:\Users\<USER>\AppData\Local\hermes\` 或 `~/.hermes/`）：

| 文件 | 路径 |
|------|------|
| gateway_state.json | `C:\Users\<USER>\AppData\Local\hermes\gateway_state.json` |
| gateway.pid | `C:\Users\<USER>\AppData\Local\hermes\gateway.pid` |
| *.lock 文件 | `C:\Users\<USER>\.local\state\hermes\gateway-locks\` |

### 从 WSL 清理（推荐）

```bash
# 删除 gateway_state.json
rm -f /mnt/c/Users/<USER>/AppData/Local/hermes/gateway_state.json

# 删除 gateway.pid
rm -f /mnt/c/Users/<USER>/AppData/Local/hermes/gateway.pid

# 删除所有锁文件
rm -f /mnt/c/Users/<USER>/.local/state/hermes/gateway-locks/*.lock
```

### 从 Windows PowerShell 清理

```powershell
Remove-Item "$env:USERPROFILE\AppData\Local\hermes\gateway_state.json"
Remove-Item "$env:USERPROFILE\AppData\Local\hermes\gateway.pid"
Remove-Item "$env:USERPROFILE\.local\state\hermes\gateway-locks\*.lock"
```

## 验证

1. 确认锁文件已删除：
```bash
ls /mnt/c/Users/<USER>/AppData/Local/hermes/gateway_state.json  # 应报错 No such file
ls /mnt/c/Users/<USER>/AppData/Local/hermes/gateway.pid         # 应报错 No such file
ls /mnt/c/Users/<USER>/.local/state/hermes/gateway-locks/       # 应为空或无 .lock 文件
```

2. 重新启动：
```powershell
hermes gateway run
```

3. 确认成功：看到 `connected to wss://msg-frontier.feishu.cn` 即为成功

## 附：GBK 编码警告

启动后可能出现大量：
```
UnicodeEncodeError: 'gbk' codec can't encode character '\u2713'
```

这是日志输出到 Windows 控制台时的编码问题，不影响实际运行，可忽略。解决方法是在 PowerShell 中先设置 UTF-8：
```powershell
chcp 65001
```

## 预防

- 更新 Hermes 前先关闭所有 Hermes 进程
- 进程异常退出后手动清理锁文件
