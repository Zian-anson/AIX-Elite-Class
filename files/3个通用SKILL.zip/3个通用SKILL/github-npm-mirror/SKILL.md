---
name: github-npm-mirror
description: 自动配置 GitHub 和 npm 国内镜像加速访问
---
# GitHub & npm 镜像配置

## 触发条件

访问 npm 或 GitHub 时速度慢、超时、无法连接

## 配置步骤

### 1. npm 镜像（阿里云）

```bash
npm config set registry https://registry.npmmirror.com
```

验证：
```bash
npm config get registry
```

### 2. GitHub（直接连接）

实测 WSL 环境下直连 GitHub 速度良好，无需镜像。如果直连超时，再启用镜像：

```bash
# 启用 GitHub 镜像（ghproxy，不稳定）
git config --global url."https://mirror.ghproxy.com/".insteadOf "https://github.com/"

# 取消镜像（恢复直连）
git config --global --unset url."https://mirror.ghproxy.com/".insteadOf
```

验证：
```bash
git config --global --list | grep insteadOf
```

### 3. 恢复官方源

```bash
# npm 恢复官方源
npm config set registry https://registry.npmjs.org
```

## 常用镜像地址

| 用途 | 镜像地址 |
|------|---------|
| npm | `https://registry.npmmirror.com` |
| GitHub (ghproxy) | `https://mirror.ghproxy.com` |

## 效果

配置后：
- `npm install xxx` → 自动走 npmmirror
- `git clone https://github.com/xxx/xxx` → 直连（若超时再启用镜像）

## 注意事项

- WSL 里配置在 `~/.gitconfig`，永久生效
- Windows Git Bash / WSL 均适用
- GitHub 镜像不稳定，实测直连效果更好
- **重要**：WSL 的 `.bashrc` 里不应有硬编码代理配置（如 `export https_proxy=http://10.255.255.254`），否则所有请求都会失败。需要代理时请临时设置：
  ```bash
  export https_proxy=http://127.0.0.1:7890  # 你的 Clash 端口
  ```
