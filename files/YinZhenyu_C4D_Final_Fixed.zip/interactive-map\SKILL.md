---
name: interactive-map
description: >
  An agent skill to convert natural language location requests into interactive maps and structured geospatial data. 
  Optimized for local inference (Gemma-4-E2B-it) on mobile devices (iOS/PocketPal AI).
  Use this skill when the user wants to visualize locations or landmarks on an interactive map.
---

# Interactive Map Agent Skill

## 1. Skill Positioning
This skill is part of the C4D Level 2 Agent Function Calling module. It converts natural language instructions into geospatial coordinates and renders them on an interactive map.

## 2. Workflow
1.  **Intent Recognition**: The Gemma-4-E2B-it model receives a natural language instruction (e.g., "Generate a map for SIAS University").
2.  **Structured Output**: The model automatically generates JSON data containing latitudes and longitudes according to the `interactive-map` schema.
3.  **Tool Call**: The system calls the map rendering engine (Folium for Python, or Google Maps plugin on mobile) to display the landmarks.

## 3. Implementation (Python Scripts)
The executable logic is located in the `scripts/` directory:
- `scripts/main.py`: Simulates the core logic of the local agent skill.
- `scripts/generate_map.py`: Fetches landmarks and creates an interactive HTML map.

## 4. Environment
- **Hardware**: iPhone 15 Pro (A17 Pro GPU acceleration).
- **Software**: PocketPal AI (iOS platform).
- **Core Model**: Gemma-4-E2B-it (Local inference).

## 5. Usage Prompt
> "Use the interactive-map skill to show the location of SIAS University and list nearby landmarks."
