# Agent 技能说明：interactive-map

### 1. 技能定位
本技能属于 C4D Level 2 要求中的 **Agent 函数调用** 模块。它允许 Gemma 4 模型将自然语言指令转化为地理空间数据坐标。

### 2. 工作流 (Workflow)
1. **意图识别**：Gemma-4-E2B-it 接收到用户指令（如：生成西亚斯地图）。
2. **结构化输出**：模型根据内置的 `interactive-map` 技能 Schema，自动生成包含经纬度的 JSON 数据。
3. **工具调用**：系统调用地图渲染引擎（手机端为 Google Maps 插件），并将 JSON 坐标点标注在视图上。

### 3. 运行环境
- **硬件**：iPhone 15 Pro (A17 Pro GPU 加速)
- **软件**：PocketPal AI (iOS 平台)
- **底层模型**：Gemma-4-E2B-it (本地运行，无 API 调用)

### 4. 触发 Prompt 示例
> "Use the interactive-map skill to show the location of SIAS University and list nearby landmarks."
