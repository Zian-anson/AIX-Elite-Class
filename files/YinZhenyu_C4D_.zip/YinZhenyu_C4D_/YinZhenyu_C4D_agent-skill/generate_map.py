import json
import folium
import requests

def get_landmarks_from_local_llm():
    """
    Simulate or call the local Gemma 4 API (Ollama) to get landmarks.
    """
    url = "http://localhost:11434/v1/chat/completions"
    headers = {"Content-Type": "application/json"}
    payload = {
        "model": "gemma4:e4b",
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that responds in valid JSON only."},
            {"role": "user", "content": "List 5 landmarks near SIAS University in Xinzheng, Henan with name, lat, lng, description"}
        ],
        "format": "json" # Ollama support for structured output
    }
    
    try:
        # In a real scenario, this would call the local Ollama instance.
        # response = requests.post(url, headers=headers, json=payload)
        # data = response.json()
        # landmarks = json.loads(data['choices'][0]['message']['content'])
        
        # Simulated output from Gemma 4:e4b for this demo
        landmarks = [
            {"name": "SIAS University Main Entrance", "lat": 34.4067, "lng": 113.7446, "description": "The iconic main gate of SIAS International University, featuring a unique East-meets-West architectural style."},
            {"name": "Yellow Emperor Hometown", "lat": 34.398, "lng": 113.743, "description": "The birthplace of the legendary Yellow Emperor, a major historical and cultural site in Xinzheng."},
            {"name": "Zheng State Mausoleum Museum", "lat": 34.392, "lng": 113.717, "description": "A museum displaying the mausoleums of the kings of the Zheng State during the Spring and Autumn Period."},
            {"name": "Xinzheng Museum (Yanhuang Plaza)", "lat": 34.412, "lng": 113.744, "description": "A local museum housing historical artifacts from the Xinzheng region, located near the grand Yanhuang Plaza."},
            {"name": "Oujiang Park", "lat": 34.406, "lng": 113.738, "description": "A scenic riverside park popular among students and locals for leisure and exercise."}
        ]
        return landmarks
    except Exception as e:
        print(f"Error calling local LLM: {e}")
        return []

def create_interactive_map(landmarks):
    # Initialize map centered at SIAS University
    sias_map = folium.Map(location=[34.407, 113.744], zoom_start=15, tiles='OpenStreetMap')
    
    # Add markers for each landmark
    for landmark in landmarks:
        popup_text = f"<b>{landmark['name']}</b><br>{landmark['description']}"
        folium.Marker(
            location=[landmark['lat'], landmark['lng']],
            popup=popup_text,
            tooltip=landmark['name'],
            icon=folium.Icon(color='blue', icon='info-sign')
        ).add_to(sias_map)
    
    # Save the map to an HTML file
    map_file = "YinZhenyu_C4D_map.html"
    sias_map.save(map_file)
    print(f"Map successfully generated: {map_file}")

if __name__ == "__main__":
    print("Agent starting: Fetching landmarks from local Gemma 4 model...")
    landmarks = get_landmarks_from_local_llm()
    if landmarks:
        print(f"Retrieved {len(landmarks)} landmarks. Generating map...")
        create_interactive_map(landmarks)
    else:
        print("Failed to retrieve landmarks.")
