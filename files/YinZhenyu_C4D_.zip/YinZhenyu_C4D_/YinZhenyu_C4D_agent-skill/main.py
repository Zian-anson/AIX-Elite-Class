import json
import folium

# 本地 Agent 技能逻辑模拟 (适配 Gemma-4-E2B-it)
def local_agent_skill_logic():
    """
    模拟 PocketPal AI 中 Gemma 4 驱动 interactive-map 的过程：
    1. 用户输入：针对 Sias University 生成地图
    2. 模型推理：识别意图并输出结构化 JSON
    3. 技能执行：调用 Folium/Google Maps 渲染
    """
    
    # 这是从你提供的截图推理出的模型 JSON 输出
    structured_output = {
        "action": "interactive-map",
        "action_input": {
            "location": "SIAS University, Zhengzhou",
            "landmarks": [
                {"name": "郑州西亚斯学院", "lat": 34.444, "lon": 113.486},
                {"name": "第五餐厅", "lat": 34.448, "lon": 113.482},
                {"name": "熊猫山谷", "lat": 34.446, "lon": 113.491}
            ]
        }
    }

    # 使用 Folium 模拟生成地图 HTML (Level 2 关键产出)
    sias_map = folium.Map(
        location=[34.444, 113.486], 
        zoom_start=15,
        tiles="OpenStreetMap"
    )

    for place in structured_output["action_input"]["landmarks"]:
        folium.Marker(
            [place["lat"], place["lon"]], 
            popup=place["name"]
        ).add_to(sias_map)

    sias_map.save("尹镇宇_C4D_map.html")
    print("Agent 技能执行完毕，交互式地图已保存。")

if __name__ == "__main__":
    local_agent_skill_logic()
