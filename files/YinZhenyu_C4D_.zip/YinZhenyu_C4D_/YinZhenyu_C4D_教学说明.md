# 尹镇宇_C4D_教学说明 (iOS 用户版)

## 1. 环境准备
### 1.1 安装 PocketPal AI
- **iOS**: 从 App Store 搜索并下载 **PocketPal AI**。
- **环境**: 确保您的 iPhone 内存空闲（建议 8GB RAM 手机，如 iPhone 15 Pro 或以上）。

### 1.2 加载模型
- 在 PocketPal AI 的模型市场搜索 **Gemma-4-E2B-it** 并完成下载。

### 1.3 开启技能插件
- 进入模型的设置选项，激活 **interactive-map** 技能。

## 2. 运行 Agent
1. **输入指令**: 
   ```text
   帮我生成一个 Sias University 周边的交互式地图。
   ```
2. **执行流程**: 
   - 模型会自动识别地理位置。
   - 调用 `interactive-map` 插件进行经纬度打点。
3. **查看结果**: 点击屏幕上的地图标记，确认定位准确性。

---

# 姓名_C4D_map.html 说明
由于手机端 PocketPal AI 产出为实时交互视图，生成的 `YinZhenyu_C4D_map.html` 文件为基于移动端渲染结果的网页版本。
（请在 `尹镇宇_C4D_output_screenshots/` 文件夹中查看实时渲染截图）。
