# 尹镇宇_C4D_方案设计

## 1. 项目名称
基于 iPhone 本地大模型的 SIAS 交互式地图 Agent

## 2. 硬件设备信息
- **设备**: iPhone 15 Pro
- **核心芯片**: A17 Pro (具备强大的端侧 GPU 算力)
- **内存**: 8GB RAM
- **运行环境**: PocketPal AI (iOS 平台本地大模型部署工具)

## 3. 模型选择与原因
- **选定模型**: **Gemma-4-E2B-it**
- **原因**: 
  1. **移动端优化**: E2B 规模专为端侧设备设计，能在 8GB 内存的 iPhone 上流畅运行。
  2. **Agent 原生支持**: 具备优秀的指令遵循和函数调用（Function Calling）能力，能够直接驱动 `interactive-map` 插件。

## 4. 实现路径
1. 在 iOS 端通过 PocketPal AI 部署本地推理环境。
2. 加载 Gemma-4-E2B-it 模型并开启 GPU 加速。
3. 激活 `interactive-map` 技能插件。
4. 输入自然语言指令，驱动模型提取地理坐标并渲染 SIAS University 地图。
