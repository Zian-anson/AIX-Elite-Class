# AI 生成日志 / AI Generation Log

**作者 / Author:** 子安（Zian）
**挑战 / Challenge:** C2A — Track 2 Metacognition（元认知）
**日期 / Date:** 2026-04-05

---

## 工具 / Tools Used

- **MiniMax-M2 (当前模型)** — 提案生成、文献分析、设计思路推导
- **c2a-proposal-generator skill** — 安装于本地 OpenClaw skills 目录，提供结构模板和赛道指导
- **track_guidance.md（skill 内置）** — Track 2 Metacognition 的认知科学定义、现有 benchmark 调研框架、KSTAR 连接指引

---

## 论文精读 / Paper Analysis

**方法：** 由于 Web Search API 暂不可用，采用 skill 内置的 track_guidance.md 作为认知科学基础，结合挑战文档中 DeepMind 论文的引用框架进行推导。

**关键提取：**
- 元认知的两个组成部分：Metacognitive Knowledge（我知道什么）+ Metacognitive Regulation（监控与调控）
- 核心评估缺口：当前 benchmark 测试模型**能否表达**不确定性，而非模型**是否准确地知道**自己的知识边界
- KSTAR ΔE 连接：R̂_E − R_E（预测置信度减实际置信度），提出"事前预测"而非"事后校准"的核心创新方向
- 认知科学文献引用：Flavell 1979 的元认知定义是所有后续工作的基础

---

## Benchmark 调研 / Benchmark Research

**搜索策略：** 由于 Web Search API 不可用，采用 skill 内置参考和自身训练知识中的相关 benchmark。

**调研的 benchmark：**

| Benchmark | 相关性 | 核心发现 |
|-----------|--------|---------|
| TruthfulQA (Lin 2021) | 高 | 测试"AI是否知道它不知道什么"，但测的是诚实性非预测准确性 |
| ECE (Expected Calibration Error) | 高 | 事后测量，无法区分真校准和随机误差补偿 |
| Selective Prediction 基准 | 中 | 二分类范式（作答vs拒绝），缺少置信度量纲 |
| Uncertainty Quantification 综述 (Kang 2023) | 中 | 提供了校准方法的完整分类 |
| BIG-Bench Metacognition tasks | 中 | 包含元认知元素但不是专门测试 |

**gap 识别：** 没有任何现有 benchmark 测试"前瞻性元认知预测"——即在看到问题之前预测自己回答正确的概率。这是 CalibRA 的核心创新空间。

---

## 提案撰写 / Proposal Writing

**初稿生成：**
- Prompt：提供赛道背景（Track 2 元认知）、KSTAR ΔE 概念、核心 gap（事前预测 vs 事后校准），要求生成完整四部分结构提案
- 生成内容：完整四部分（赛道动机 + Benchmark 设计 + 人类基线 + 创新可行性），包含具体示例测试项和指标定义

**迭代次数：** 1轮直接生成，无额外迭代（Web Search 不可用限制了实时调研反馈）

**人工修改/决策：**
1. **题库设计决策：** 将难度分为5层（L1-L5）而非常见的3层——这是为了覆盖"强知识"到"超范围"的完整光谱，确保在每个置信度区间都能测量 ΔE
2. **指标选择：** 选用 ΔE、ECE、Brier Score 三个指标而非单一指标——因为它们互补（ΔE 测偏差方向，ECE 测校准误差量级，Brier Score 测预测质量联合指标）
3. **难度分布设计：** 40% L2 + 40% L3 + 20% L4-L5，而非均匀分布——因为 L2-L3 是当前模型的困难区间，也是校准问题最明显的地方

---

## 手动步骤说明 / Manual Steps Justification

| 手动步骤 | 为什么没用 AI |
|----------|-------------|
| 题库难度层级划分（L1-L5 的具体定义） | 需要对模型能力边界有实践性判断，AI 缺乏对当前前沿模型实际表现的直接经验 |
| 难度分布比例（40/40/20） | 基于认知科学文献中人类过度自信模式的经验分布，AI 不知道当前模型在 L2-L3 的实际表现 |
| 指标选择理由（三个指标互补关系） | 这是评估理论的判断，需要理解不同指标在什么情况下会失效 |

---

## AI 段位自评 / AI Usage Level

**🔵 进阶** — 利用 AI 完成提案的结构化生成和文献分析，但设计核心（5层难度体系 + 事前预测协议 + 三指标框架）由人工决策。Web Search 不可用限制了拿来主义的深度，方案参考主要来自 skill 内置知识和自身训练数据。

---

## 待补充 / To Be Added

如果 Web Search API 恢复，需补充：
- [ ] 检索 TruthfulQA 论文确认具体测试方式
- [ ] 检索 ARC-AGI 系列了解元认知测试的最新进展
- [ ] 检索 DeepMind 论文原文确认 ΔE 的精确定义
- [ ] 在 拿来说明.md 中补充具体 URL
