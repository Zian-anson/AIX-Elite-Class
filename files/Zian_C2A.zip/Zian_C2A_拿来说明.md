# 拿来说明 / Attribution

## 借鉴来源 / References

| 来源 / Source | 核心思想 / Key Idea | 链接 / URL |
|---------------|---------------------|-----------|
| TruthfulQA (Lin et al., 2021) | "模型不知道自己不知道什么"是核心问题；测试框架用"回答+置信度"分离 | https://arxiv.org/abs/2109.07958 |
| ECE (Expected Calibration Error) | 分箱计算预测概率与实际准确率的对齐程度 | 认知科学通用方法 |
| Flavell (1979) 元认知理论 | 元认知 = Metacognitive Knowledge + Metacognitive Regulation | https://doi.org/10.1037/0003-066X.34.10.906 |
| KSTAR ΔE 框架 | ΔE = R̂_E − R_E，预测置信度与实际置信度的偏差 | Elite 20 课程材料 |
| Selective Prediction 研究 | 置信度连续光谱优于二分类（作答/拒绝） | Kang et al. (2023) Uncertainty Survey |
| 认知科学校准研究 | 人类在组合推理问题（L2）上系统性过度自信 | 心理学文献共识 |

---

## 拿来的部分 / Adopted

### 从 TruthfulQA
- **拿了什么：** "模型对不确定问题的响应方式"这个核心问题意识，以及用置信度表达来测量元认知的范式
- **为什么好用：** TruthfulQA 证明了"问模型不知道什么"是可操作的评估范式，有成熟的评测框架可参考

### 从 ECE
- **拿了什么：** 分箱计算校准误差的方法论，以及"预测概率-实际准确率"的对齐思想
- **为什么好用：** ECE 是校准领域的标准指标，简单、可解释，能直接应用于我们的评分

### 从 Flavell (1979)
- **拿了什么：** 元认知的双组件定义（知识 + 调控）作为 benchmark 设计的理论基础
- **为什么好用：** Flavell 的定义是认知科学界元认知概念的起点，为我们的设计提供了扎实的学科基础

### 从 KSTAR ΔE
- **拿了什么：** ΔE = R̂_E − R_E 这个公式，直接作为核心评估指标的理论基础
- **为什么好用：** 将抽象的认知偏差概念量化为可计算的指标，使 benchmark 有明确的评分函数

---

## 去掉的部分 / Removed

### 从 TruthfulQA
- TruthfulQA 的评测重点是"回答的真实性"（是否复述人类错误信念），而非"置信度预测的准确性"
- 我去掉了真/假信念的二分类框架，改为连续概率预测，因为连续概率能更精确地测量校准程度

### 从 ECE
- 传统 ECE 只做事后校准分析，无前瞻性预测要求
- 我去掉了"事后"这个限制，加入了"Pre-Answer Prediction"这个事前环节——这是最关键的设计改变

### 从 Selective Prediction
- Selective Prediction 只要求模型在低置信时拒绝回答（二分类），无法测量置信度的量纲精度
- 我去掉了二分类范式，改为连续概率预测，以保留更丰富的校准信息

---

## 我的改进 / My Improvements

### 创新1：事前预测协议（Pre-Answer Confidence Prediction）
- **改进了什么：** 在 TruthfulQA 和 ECE 的"答后评估"范式中加入了"答前预测"环节
- **效果：** 打破事后校准无法区分"真元认知"和"随机误差补偿"的问题，直接测量前瞻性元认知能力

### 创新2：5层难度题库（Known-Unknown Spectrum）
- **改进了什么：** 将题库从传统的"会/不会"二级扩展为 L1-L5 的五级难度光谱
- **效果：** 确保模型在每个置信度区间（0-100%）都有对应的测试题，能绘制完整的 calibration curve，而非只有单一指标

### 创新3：ΔE 作为核心指标
- **改进了什么：** 将 KSTAR 的 ΔE 概念从理论公式转化为可计算的 benchmark 指标
- **效果：** 打通了 KSTAR 课程框架与 benchmark 评估的连接，使方案与课程内容深度绑定

### 创新4：KSTAR 课程绑定
- **改进了什么：** 明确标注了方案与 KSTAR 框架（ΔE、认知偏差）的对应关系
- **效果：** 评审者能看到方案直接源于 KSTAR 课程内容，而非 generic AI 评测思路

---

## 待补充 / To Be Added

（Web Search API 不可用时暂时留空，恢复后补充具体 URL 和论文页码）
- [ ] TruthfulQA 原文链接（当前仅有 arxiv ID）
- [ ] Flavell 1979 原文 DOI（需确认）
- [ ] Kang 2023 Uncertainty Survey 具体引用信息
