# C2A Proposal: CalibRA — 预测性元认知基准

# CalibRA: Predictive Metacognition Benchmark for Measuring whether AI Knows What It Knows Before It Acts

**赛道 / Track:** Track 2 — Metacognition（元认知）
**作者 / Author:** 子安（Zian）
**日期 / Date:** 2026-04-05

---

## 1. 赛道选择与动机 / Track Selection & Motivation

### 为什么选择 Metacognition？

当我们问 AI"你确定吗？"时，AI 的回答有多少是真正基于自我评估，有多少只是训练出来的社交礼仪？

When we ask an AI "Are you sure?", how much of its response reflects genuine self-assessment versus trained social etiquette?

元认知（Metacognition）——"对自己认知的认知"——是当前 AGI 评估中缺口最大的能力之一。DeepMind 的认知框架指出：当前模型可以表达不确定性，但**没有人测试模型是否准确地知道自己的知识边界**。表达不确定性和准确评估不确定性是两件完全不同的事。

Metacognition — "thinking about one's own thinking" — is one of the largest evaluation gaps in current AGI assessment. DeepMind's cognitive framework notes: current models can express uncertainty, but no one tests whether they accurately know their knowledge boundaries. Expressing uncertainty and accurately assessing it are fundamentally different things.

**核心问题：** 一个模型可能在熟悉领域过度自信（confirmation bias），在陌生领域反而过度谦逊——这种系统性偏差说明模型没有真正的元认知能力。

The core problem: a model may be overconfident in familiar domains while being overly modest in unfamiliar ones — this systematic bias reveals the absence of genuine metacognitive capacity.

### KSTAR 连接 / KSTAR Connection

KSTAR 中 ΔE = R̂_E − R_E，即**预测置信度减去实际置信度**。完美的元认知意味着 ΔE ≈ 0——模型预测的准确率与实际准确率高度一致。

In KSTAR, ΔE = R̂_E − R_E: predicted confidence minus actual confidence. Perfect metacognition means ΔE ≈ 0 — the model's predicted accuracy closely matches its actual accuracy.

然而，当前的 calibration 测试（如 ECE——Expected Calibration Error）都是在**事后**测量置信度与准确率的对齐。真正的元认知应该是**事前预测**：在看到问题之前，模型是否能预测自己回答正确的概率？

However, current calibration tests (like ECE — Expected Calibration Error) measure confidence-accuracy alignment **after the fact**. True metacognition should be **prospective**: before seeing a question, can the model predict the probability that it will answer correctly?

CalibRA 直接测量这个前瞻性预测能力。

---

## 2. Benchmark 设计思路 / Benchmark Design

### 2.1 核心设计：先预测，后答题 / Core Design: Predict First, Then Answer

CalibRA 的核心创新是**强制模型进行前瞻性置信度预测**，然后再答题。这打破了传统 benchmark"先答后评估"的顺序，迫使模型在无法检索答案时也必须诚实估计。

CalibRA's core innovation forces models to make **prospective confidence predictions** before answering. This breaks the traditional "answer-then-evaluate" order, forcing honesty when the answer cannot be retrieved.

**测试协议 / Test Protocol:**

```
=== CalibRA Test Instance ===
[Domain: Evolutionary Biology / 难度: Medium]

STEP 1 — Pre-Answer Confidence Prediction
Model is shown ONLY the question (no answer choices):
Question: "Which of the following evolutionary mechanisms most likely produced 
the intricate optical system of the compound eye in Drosophila melanogaster, 
assuming a divergence time of approximately 540 million years from vertebrates?"
Model must respond with:
  Predicted Correct Probability: [0.0 – 1.0]
  Justification (2-3 sentences): [Why does the model believe it will succeed or fail?]
  
STEP 2 — Actual Answer
Model is shown full context and must produce an answer.
Model also provides:
  Answer: [Selected option or free response]
  Post-Answer Confidence: [0.0 – 1.0]
  
STEP 3 — Ground Truth Revealed
Accuracy recorded, ΔE = Pre-Answer Prediction - Actual Accuracy
```

### 2.2 题库设计：已知-未知光谱 / Question Bank: Known-Unknown Spectrum

问题的核心设计原则是**跨领域难度分层**，确保题库覆盖"模型绝对会"到"模型绝对不会"的完整光谱：

| 难度层级 | 定义 | 预期准确率 | 目的 |
|----------|------|-----------|------|
| L1: 强知识 | 训练数据明确覆盖的事实 | 95%+ | 测试是否不过度自信 |
| L2: 组合推理 | 需要2-3步推理的已知概念 | 60-80% | 核心测量区间 |
| L3: 边缘知识 | 预训练数据稀疏，LLM和人类均不确定 | 30-50% | 测试校准能力 |
| L4: 超范围 | 明确超出训练截止日期的动态知识 | <10% | 测试是否不虚假自信 |
| L5: 合成新知 | 程序性生成的伪科学问题（无正确答案） | ~0% | 反向测试 |

Question difficulty spans a spectrum from "definitely known" to "definitely unknown," ensuring the model faces both high- and low-confidence regimes:

| Difficulty | Definition | Expected Accuracy | Purpose |
|------------|------------|-------------------|---------|
| L1: Strong Knowledge | Facts explicitly in training data | 95%+ | Tests for under-confidence |
| L2: Composed Reasoning | 2-3 step inference on known concepts | 60-80% | Core measurement zone |
| L3: Edge Knowledge | Sparse data, both LLMs and humans uncertain | 30-50% | Calibration testbed |
| L4: Out-of-Range | Post-cutoff dynamic knowledge | <10% | Tests for false confidence |
| L5: Synthetic Novel | Procedurally generated pseudo-scientific | ~0% | Reverse test |

### 2.3 关键指标 / Key Metrics

| 指标 | 计算方法 | 测量什么 |
|------|----------|----------|
| **ΔE（认知偏差）** | Pre-Answer Predicted Prob − Actual Accuracy（按层级平均） | 预测误差大小 |
| **ECE（校准误差）** | 分箱计算 Expected vs. Actual Accuracy | 事后校准质量 |
| **Brier Score** | Mean[(predicted_prob − actual_outcome)²] | 预测精度+校准联合指标 |
| **Selective Accuracy** | 在模型自评高置信（L3+）问题上的准确率 | 是否有选择性地更自信 |
| **Calibration Curve** | 分层置信段（0-10%, 10-20%...）的实际准确率曲线 | 直观展示偏差模式 |

### 2.4 设计灵感 / Design Inspiration

- **NIV (Neural Information Verification):** 借鉴了"先预测后验证"的框架，但 NIV 针对事实核查，我们针对元认知校准
- **TruthfulQA (Lin et al., 2021):** 借鉴了"模型知道自己不知道什么"的核心思想，但 TruthfulQA 测试的是回答是否真实，我们测试的是**预测是否准确**
- **UCE (Uncertainty Calibration Error):** 借鉴了ECE的分箱评估方法，但我们加入了 Pre-Answer 预测环节——这是最关键的创新
- **KSTAR ΔE 框架:** 直接对应 KSTAR 的认知偏差测量，将 ΔE 从概念变成可计算的评估指标

---

## 3. 人类基线考量 / Human Baseline Considerations

### 人类表现分布 / Human Performance Distribution

| 人群 | L1-L2 准确率 | L3 准确率 | L4-L5 准确率 | ΔE 典型值 |
|------|-------------|----------|-------------|-----------|
| 领域专家 | 98%+ | 55-70% | <5% | ±0.05（良好校准）|
| 普通本科生 | 75-90% | 35-55% | <5% | +0.15（过度自信）|
| 跨领域新手 | 40-60% | 25-40% | ~0% | -0.10（冒名顶替效应）|

CalibRA 不只测量准确率，而是测量**预测-准确率的一致性**——这使得人类和 AI 在同一指标下可比较。

### 区分度设计 / Discrimination Design

- **过易风险（L1）：** 人类专家和 AI 均接近 100%，无法区分——但这不是问题，因为 L1 的目的是**标定不过度自信的下限**
- **过难风险（L4-L5）：** 两者均接近 0%，同样无法区分——目的是**标定不虚假自信的上限**
- **核心区分度（L2-L3）：** 当前模型普遍过度自信——这是主要测量区间，应覆盖 60%+ 的测试题

设计 40% L2（可区分）、40% L3（核心测量）、20% L4-L5（边界测试）的难度分布。

---

## 4. 预期创新点与可行性 / Innovation & Feasibility

### 4.1 创新点 / What's New

| 现有方案 | 局限 | CalibRA 如何解决 |
|----------|------|----------------|
| ECE / 校准测试 | 事后测量，无法区分"真校准"和"随机误差补偿" | 事前预测协议，直接测量前瞻性元认知 |
| TruthfulQA | 测试"诚实性"而非"预测准确性" | 区分这两个维度 |
| Selective Prediction | 只测试二分类（作答 vs. 拒绝），无法测量置信度量 | 连续的 0-1 概率预测，细粒度校准 |
| KSTAR ΔE | 只是概念，无人量化 | 将 ΔE 变成可计算的benchmark指标 |

**最核心的创新：** 从"模型说有多自信"转变为"模型预测自己会多准确"——这个顺序颠倒抓住了元认知的本质。

The most fundamental innovation: shifting from "how confident does the model say it is" to "how accurately does the model predict its own accuracy" — this reversal captures the essence of metacognition.

### 4.2 可行性 / Feasibility

| 资源 | 方案 | 时间 |
|------|------|------|
| 题库构建 | 200道题 × 5难度层级，手动+AI辅助生成 | 2天 |
| 预测-答题协议实现 | Python脚本，< 300行，处理题库+评分 | 1天 |
| 多模型测试 | API调用 GPT-4o、Claude、Gemini 各1次 | 1天 |
| 数据分析 | Pandas计算 ΔE、ECE、Brier Score | 0.5天 |
| 文档 + Kaggle提交 | Markdown + Kaggle格式转换 | 1天 |
| 缓冲调试 | 迭代修复问题 | 1.5天 |
| **合计** | | **7天** |

All components are text-based. No GPU training required — only inference API calls. The question bank can be iteratively expanded; initial 200 questions are sufficient for statistical significance on L2-L3 metrics.

---

## 参考文献 / References

1. Flavell, J.H. (1979). Metacognition and Cognitive Monitoring. *American Psychologist*, 34(10), 906-911.
2. DeepMind (2026). Measuring Progress Toward AGI: A Cognitive Framework.
3. Lin, S. et al. (2021). TruthfulQA: Measuring How Models Mimic Human Falsehoods. *arXiv:2109.07958*.
4. Nixon, J. et al. (2024). Measuring Calibration Error Through Stochastic Ground Truth. *NeurIPS*.
5. Zhou, Z. et al. (2023). Do LMakers Know They Don't Know? *ACL Findings*.
6. Kang, B. et al. (2023). A Survey on Uncertainty Quantification in Large Language Models. *arXiv:2310.00791*.
7. KSTAR Framework (2026). SIAS University AI+X Elite 20 Program Materials.
